<?php
error_reporting(0);
/* Database credentials. */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'cryptfin_nance');
define('DB_PASSWORD', 'cryptfin_nance');
define('DB_NAME', 'cryptfin_nance');
 
/* Attempt to connect to MySQL database */
$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}

/* Site info. */
$site_name = "Crypto Finance Investment";
$logo_url = "https://cryptfinanceinvest.com/Mooncoinlogo.jpg";
$email_logo_url = "https://cryptfinanceinvest.com/Mooncoinlogo.jpg";
$site_url = 'https://cryptfinanceinvest.com';
$support_email = "support@cryptfinanceinvest.com";
$phonenumber = '+15408357251';
$address = '1280 West Harrison St.
Chicago, Illinois 60607';

/* wallet */
$btc = 'bc1qsa9hppj3hmn6unchvvqnftcrpd56crpkr4u6d3';
$ethereum = '0x6883A262CB36657e76B7D61EFef244F942Fb2391';

/* stop editing. */
function random_str(
    int $length = 64,
    string $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
): string {
    if ($length < 1) {
        throw new \RangeException("Length must be a positive integer");
    }
    $pieces = [];
    $max = mb_strlen($keyspace, '8bit') - 1;
    for ($i = 0; $i < $length; ++$i) {
        $pieces []= $keyspace[random_int(0, $max)];
    }
    return implode('', $pieces);
}
?>