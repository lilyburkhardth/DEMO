<?php
require_once('header.php');
?>
<!-- END SIDEBAR-->
<div class="content-wrapper">
    <!-- START PAGE CONTENT-->

    <div class="page-heading">
        <h1 class="page-title" style="color: #FFF;">Upgrade Trade</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php"><i class="la la-home font-20"></i></a>
            </li>
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <div class="ibox">
            <div class="ibox-head">
                <div class="ibox-title">Upgrade Package</div>
            </div>
            <div class="ibox-body">
                <center>
                    <div class="up_bx">
                        <div class="_upGH">Starter</div>
                        <div class="_upGP">$2,000.00</div>
                        <div class="_upTXT">24x7 Support</div>
                        <div class="_upTXT">Professional Charts</div>
                        <div class="_upTXT">Trading Alerts</div>
                        <div class="_upTXT">Trading Central Starter</div>
                        <div class="_upTXT">6,500 USD Bonus</div>
                        <div class="_upgrade_" amt="2000" pck="STARTER">UPGRADE</div>
                    </div>

                    <div class="up_bx">
                        <div class="_upGH">Bronze</div>
                        <div class="_upGP">$3000.00</div>
                        <div class="_upTXT">24x7 Support</div>
                        <div class="_upTXT">Professional Charts</div>
                        <div class="_upTXT">Trading Alerts</div>
                        <div class="_upTXT">Trading Central Bronze</div>
                        <div class="_upTXT">8,500 USD Bonus</div>
                        <div class="_upgrade_" amt="3000" pck="BRONZE">UPGRADE</div>
                    </div>
                    <div class="up_bx">
                        <div class="_upGH">Silver</div>
                        <div class="_upGP">$7,000.00</div>
                        <div class="_upTXT">24x7 Support</div>
                        <div class="_upTXT">Professional Charts</div>
                        <div class="_upTXT">Trading Alerts</div>
                        <div class="_upTXT">Trading Central Silver</div>
                        <div class="_upTXT">Live Trading With Experts</div>
                        <div class="_upTXT">SMS & EMail Alerts</div>
                        <div class="_upTXT">36,000 USD Bonus</div>

                        <div class="_upgrade_" amt="4000" pck="SILVER">UPGRADE</div>
                    </div>
                    <div class="up_bx">
                        <div class="_upGH">Diamond</div>
                        <div class="_upGP">$36,000.00</div>
                        <div class="_upTXT">24x7 Support</div>
                        <div class="_upTXT">Professional Charts</div>
                        <div class="_upTXT">Trading Alerts</div>
                        <div class="_upTXT">Trading Central Basic</div>
                        <div class="_upTXT">Live Trading With Experts</div>
                        <div class="_upTXT">SMS & EMail Alerts</div>
                        <div class="_upTXT">43,000 USD Bonus</div>

                        <div class="_upgrade_" amt="5000" pck="DIAMOND">UPGRADE</div>
                    </div>
                    <div class="up_bx">
                        <div class="_upGH">Gold</div>
                        <div class="_upGP">$68,000.00</div>
                        <div class="_upTXT">24x7 Support</div>
                        <div class="_upTXT">Professional Charts</div>
                        <div class="_upTXT">Trading Alerts</div>
                        <div class="_upTXT">Trading Central Basic</div>
                        <div class="_upTXT">Live Trading With Experts</div>
                        <div class="_upTXT">SMS & EMail Alerts</div>
                        <div class="_upTXT">89,000 USD Bonus</div>
                        <div class="_upgrade_" amt="6000" pck="GOLD">UPGRADE</div>
                    </div>
                </center>
            </div>
        </div>
    </div>
    <!-- END PAGE CONTENT-->
    <?php
    require_once('footer.php');
    ?>