<?php
require_once('../config.php');
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: /login.php");
    exit;
}
$id = $_SESSION["id"];
$sql = "SELECT * FROM users WHERE id='$id'";
$result = $mysqli->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $current_user_id = $row['id'];
    $user_data = $row;
} else {
    header("location: /login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Dashboard | <?php echo $site_name; ?></title>
    <link rel="icon" type="image/icon" href="../images/favicon.png">
    <link href="assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="assets/vendors/themify-icons/themify-icons.css" rel="stylesheet" />
    <link href="assets/vendors/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
    <link href="assets/css/bootstrap-imageupload.css" rel="stylesheet">
    <link href="assets/css/main.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <style type="text/css">
        ._w89 {
            width: 80% !important;
            margin-top: 10px;
            border-radius: 3px;
            display: block;
            overflow: hidden;
        }

        #cWIIT {
            opacity: 0;
            height: 0px;
            width: 0px;
            position: fixed;
            top: 0;
        }

        ._pay_now,
        ._pay_now_ {
            cursor: pointer;
        }

        .up_bx {
            width: 240px;
            display: inline-block;
            background: #FFF;
            border: 1px dashed #00afef;
            box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.1);
            margin-bottom: 10px;
        }

        ._upGH {
            font-size: 35px;
            font-weight: 900;
        }

        ._upGP {
            font-size: 24px;
            margin-bottom: 10px;
            color: #00AFEF;
            font-weight: 900;
        }

        ._upTXT {
            font-size: 15px;
            padding: 10px;
            border-top: 1px dashed #00AFEF;
        }

        ._upgrade_ {
            background: #00afef;
            padding: 10px;
            font-weight: 800;
            color: #FFF;
            cursor: pointer;
            margin: 0px;
        }

        table {
            margin-right: 15px;
        }

        ._npane {
            width: 100%;
            position: fixed;
            overflow: hidden;
            overflow-y: scroll;
            height: 100%;
            background: rgba(150, 150, 150, 0.5);
            z-index: 10000;
            display: none;
        }

        ._nmod {
            width: 80%;
            margin: 50px auto;
            max-width: 500px;
            background: #FFF;
            box-shadow: 2px 2px 2px rgba(0, 0, 0, 0.2);
            padding: 20px;
            border-radius: 5px;
        }

        ._mod_head {
            width: 100%;
            display: block;
            overflow: hidden;
            font-size: 20px;
            margin-bottom: 10px;
        }

        ._mod_text {
            width: 100%;
            display: block;
            overflow: hidden;
            line-height: 1.2;
            margin-bottom: 10px;
            padding: 10px;
            border-bottom: 1px dashed #9e9e9e;
            border-top: 1px dashed #9e9e9e;
        }

        ._mod_close {
            width: 50%;
            display: block;
            overflow: hidden;
            background: #cddc39;
            padding: 12px 10px;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
        }

        ._nnp_btn {
            text-align: center;
            padding: 5px 10px;
            cursor: pointer;
            float: right;
            border-radius: 2px;
            background: #1d1d1d;
            color: #FFF;
            display: block;
            overflow: hidden;
            width: 100%;
        }

        ._phh {
            text-align: center;
            font-weight: bolder;
            font-size: 14px;
            margin-bottom: 10px;
        }

        ._seg_pay {
            width: 48%;
            display: inline-block;
            overflow: hidden;
            float: left;
            margin: 1%;
            background: #FFF;
            border-radius: 2px;
            padding: 20px;
        }

        ._seg_pay_img_ {
            height: 30px;
            max-width: 100%;
            display: block;
            overflow: hidden;
        }

        ._gwAA {
            margin-top: 20px;
            width: 100%;
        }
    </style>
</head>

<body class="fixed-navbar">
    
    <!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+15408357251", // WhatsApp number
            call_to_action: "Message us", // Call to action
            button_color: "#FF6550", // Color of button
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = 'https:', host = "getbutton.io", url = proto + '//static.' + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->
    
    <div class="page-wrapper">
        <!-- START HEADER-->
        <header class="header">
            <div class="page-brand">
                <a class="link" href="index.php">
                    <span class="brand"><?php echo $site_name; ?>
                    </span>
                    <span class="brand-mini">QxE</span>
                </a>
            </div>
            <div class="flexbox flex-1">
                <!-- START TOP-LEFT TOOLBAR-->
                <ul class="nav navbar-toolbar">
                    <li>
                        <a class="nav-link sidebar-toggler js-sidebar-toggler"><i style="color: white;" class="ti-menu"></i></a>
                    </li>
                </ul>
                <!-- END TOP-LEFT TOOLBAR-->
                <!-- START TOP-RIGHT TOOLBAR-->
                <div id="ytWidget"></div><script src="https://translate.yandex.net/website-widget/v1/widget.js?widgetId=ytWidget&pageLang=en&widgetTheme=dark&autoMode=true" type="text/javascript"></script>
                <ul class="nav navbar-toolbar">
                    <li class="dropdown dropdown-inbox">
                
                        <ul class="dropdown-menu dropdown-menu-right dropdown-menu-media">
                            <li class="dropdown-menu-header">
                                <div>
                                    <a class="pull-right" href="#ee">+<?php echo rand('1', '99'); ?>%</a>
                                </div>
                            </li>
                            <li class="list-group list-group-divider scroller" data-height="240px" data-color="#71808f">
                                <div>
                                    <?php
                                    $array = range(1, $alert);
                                    foreach ($array as $arr) {
                                    ?>
                                        <a class="list-group-item">
                                            <div class="media">
                                                <div class="media-body">
                                                </div>
                                            </div>
                                        </a>

                                    <?php } ?>

                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown dropdown-user">
                        <a class="nav-link dropdown-toggle link" data-toggle="dropdown" style="color: #23b7e5;">
                            <img src="./assets/img/admin-avatar.png" />
                            <span></span>Hi!, <?php echo htmlspecialchars($_SESSION["username"]); ?><i class="fa fa-angle-down m-l-5"></i></a>
                        <ul class="dropdown-menu dropdown-menu-right">
                             <a class="dropdown-item" href="edit-profile.php" ><i class="fa fa-edit"></i>Edit Profile</a>
                            <a class="dropdown-item" href="mailto:@<?php echo $support_email; ?>" target="_blank"><i class="fa fa-support"></i>Support</a>
                            <li class="dropdown-divider"></li>
                            <a class="dropdown-item" href="logout.php"><i class="fa fa-power-off"></i>Logout</a>
                        </ul>
                    </li>
                </ul>
                <!-- END TOP-RIGHT TOOLBAR-->
            </div>
        </header>
        <!-- END HEADER-->
        <!-- START SIDEBAR-->
        <nav class="page-sidebar" id="sidebar">
            <div id="sidebar-collapse">
                <div class="admin-block d-flex">
                    <div>
                        <img src="assets/img/admin-avatar.png" width="45px" />
                    </div>
                    <div class="admin-info">
                        <div class="font-strong"><?php echo htmlspecialchars($_SESSION["username"]); ?></div>
                        <small class="text-success">Verified</small>
                    </div>
                </div>
                <ul class="side-menu metismenu">
                    <li>
                        <a href="index.php"><i class="sidebar-item-icon ti-signal"></i>
                            <span class="nav-label">Trade Center</span>
                        </a>
                    </li>
                    <li>
                        <a href="deposit.php"><i class="sidebar-item-icon ti-money"></i>
                            <span class="nav-label">Fund Account</span>
                        </a>
                    </li>
                    <li>
                        <a href="withdraw.php"><i class="sidebar-item-icon ti-credit-card"></i>
                            <span class="nav-label">Place Withdraw</span>
                        </a>
                    </li>
                    <li>
                        <a href="upgrade.php"><i class="sidebar-item-icon ti-bolt"></i>
                            <span class="nav-label">Upgrade Trade</span>
                        </a>
                    </li>
                    <!--
                    <li>
                        <a href="trade-history.php"><i class="sidebar-item-icon ti-bar-chart"></i>
                            <span class="nav-label">Trade History</span>
                        </a>
                    </li>
                    <li>
                        <a href="id-verification.php"><i class="sidebar-item-icon fa fa-id-card"></i>
                            <span class="nav-label">ID Verification</span>
                        </a>
                    </li>
                    -->
                    <li>
                        <a href="edit-profile.php"><i class="sidebar-item-icon ti-pencil"></i>
                            <span class="nav-label">Update Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="update-password.php"><i class="sidebar-item-icon ti-lock"></i>
                            <span class="nav-label">Update Password</span>
                        </a>
                    </li>
                    <li>
                        <a href="#profile" class="_pprofile__"><i class="sidebar-item-icon ti-user"></i>
                            <span class="nav-label">Profile</span>
                        </a>
                    </li>
                    <li>
                        <a href="top-investors.php"><i class="sidebar-item-icon ti-star"></i>
                            <span class="nav-label">Top Investors</span>
                        </a>
                    </li>
                    <li>
                        <a href="recent-withdraw.php"><i class="sidebar-item-icon ti-crown"></i>
                            <span class="nav-label">Recent Withdraw</span>
                        </a>
                    </li>
                    <?php
                    if ($user_data['role'] == '1') {
                    ?>
                        <!--<li>-->
                        <!--    <a href="admin.php"><i class="sidebar-item-icon ti-user"></i>-->
                        <!--        <span class="nav-label">Admin</span>-->
                        <!--    </a>-->
                        <!--</li>-->
                    <?php } ?>
                    <li>
                        <a href="logout.php"><i class="sidebar-item-icon ti-close"></i>
                            <span class="nav-label">Log Out</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>