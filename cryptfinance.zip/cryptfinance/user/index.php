<?php
require_once('header.php');
?>
<div class="content-wrapper">

    <div class="page-content fade-in-up">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="ibox bg-success color-white widget-stat" style="background: #1e88e5 !important; border-radius: 10px;">
                    <div class="ibox-body">
                        <h2 class="m-b-5 font-strong">$<?php echo number_format($row['total_balance'], 2); ?></h2>
                        <div class="m-b-5">BALANCE</div><i class="ti-money widget-stat-icon"></i>
                        <div><i class="fa fa-level-up m-r-5"></i><small><?php echo rand('1', '99'); ?>% higher</small></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="ibox bg-info color-white widget-stat" style="background: #ffb302 !important; border-radius: 10px;">
                    <div class="ibox-body">
                        <h2 class="m-b-5 font-strong">
                            <?php echo file_get_contents('https://blockchain.info/tobtc?currency=USD&value=' . $row['total_balance']); ?>BTC</h2>
                        <div class="m-b-5">BTC EQUIVALENT</div><i class="fa fa-bitcoin widget-stat-icon"></i>
                        <div><i class="fa fa-level-up m-r-5"></i><small><?php echo rand('1', '99'); ?>% higher</small></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="ibox bg-warning color-white widget-stat" style="background: #1e88e5 !important; border-radius: 10px;">
                    <div class="ibox-body">
                        <h2 class="m-b-5 font-strong">$<?php echo number_format($row['balance'], 2); ?></h2>
                        <div class="m-b-5">PROFIT</div><i class="fa fa-money widget-stat-icon"></i>
                        <div><i class="fa fa-level-up m-r-5"></i><small><?php echo rand('1', '99'); ?>% higher</small></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="ibox bg-warning color-white widget-stat" style="background: #1e88e5 !important; border-radius: 10px;">
                    <div class="ibox-body">
                        <h2 class="m-b-5 font-strong">$<?php echo number_format($row['bonus'], 2); ?></h2>
                        <div class="m-b-5">BONUS</div><i class="fa fa-money widget-stat-icon"></i>
                        <div><i class="fa fa-level-up m-r-5"></i><small><?php echo rand('1', '99'); ?>% higher</small></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="ibox bg-danger color-white widget-stat" style="background: #0d755d !important; border-radius: 10px;">
                    <div class="ibox-body">
                        <h2 class="m-b-5 font-strong"><?php echo number_format($row['deposit'], 2); ?></h2>
                        <div class="m-b-5">DEPOSIT</div><i class="fa fa-money widget-stat-icon"></i>
                        <div><i class="fa fa-level-up m-r-5"></i><small><?php echo rand('1', '99'); ?>% higher</small></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="ibox bg-danger color-white widget-stat" style="background: #3ec3c3 !important; border-radius: 10px;">
                    <div class="ibox-body">
                        <h2 class="m-b-5">Refer Friends. Get Rewarded</h2>
                        <div class="m-b-5">You can earn $1,000 Referral Reward for each approved referral</div>
                        <div class="_reff" style="background: #32a2a2; border-radius: 5px; text-align: center; padding: 5px; cursor: pointer;"><i class="fa fa-level-down m-r-5"></i><small>Become a referral</small></div>
                    </div>
                </div>
            </div>
        </div>


        <!-- TradingView Widget BEGIN -->
        <div class="tradingview-widget-container">
            <div id="tradingview_19631"></div>
            <div class="tradingview-widget-copyright"></div>
            <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
            <script type="text/javascript">
                new TradingView.widget({
                    "width": "auto",
                    "height": 498,
                    "symbol": "COINBASE:BTCUSD",
                    "interval": "D",
                    "timezone": "Etc/UTC",
                    "theme": "Dark",
                    "style": "0",
                    "locale": "en",
                    "toolbar_bg": "#f1f3f6",
                    "enable_publishing": false,
                    "allow_symbol_change": true,
                    "hotlist": true,
                    "container_id": "tradingview_19631"
                });
            </script>
        </div>
        <!-- TradingView Widget END -->

        <div class="row mt-4">
            <div class="col-12">
                <div class="ibox">
                    <div class="ibox-body">
                        <div class="flexbox mb-4">
                            <div class="d-inline-flex">
                                <div class="px-3" style="border-right: 1px solid rgba(0,0,0,.1);">
                                    <div class="text-muted">WEEKLY DEPOSIT</div>
                                    <div>
                                        <span class="h5 m-0">$155,389</span>
                                        <span class="text-success ml-2"><i class="fa fa-level-up"></i> +99%</span>
                                    </div>
                                </div>
                                <div class="px-3">
                                    <div class="text-muted">WEEKLY WITHDRAW</div>
                                    <div>
                                        <span class="h5 m-0">183,642</span>
                                        <span class="text-warning ml-2"><i class="fa fa-level-down"></i> -25%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <canvas id="bar_chart" style="height:260px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style type="text/css">
            svg {
                width: 100% !important;
            }
        </style>
        <script type="text/javascript">
            $(document).ready(function() {
                $("svg").css({
                    "width": "100%"
                });
            })
        </script>
        <div class="row">
            <div class="col-12">
                <div class="ibox">
                    <div class="ibox-head">
                        <div class="ibox-title">Visitors Statistics</div>
                    </div>
                    <div class="ibox-body">
                        <div id="world-map" style="height: 300px;"></div>
                        <table class="table table-striped m-t-20 visitors-table">
                            <thead>
                                <tr>
                                    <th>Country</th>
                                    <th>Visits</th>
                                    <th>Data</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <img class="m-r-10" src="./assets/img/flags/us.png" />USA
                                    </td>
                                    <td>5572</td>
                                    <td>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-success" role="progressbar" style="width:64%; height:5px;" aria-valuenow="46" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <span class="progress-parcent">89%</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img width="24" class="m-r-10" src="./assets/img/flags/Canada.png" />Canada
                                    </td>
                                    <td>8308</td>
                                    <td>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-warning" role="progressbar" style="width:25%; height:5px;" aria-valuenow="48" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <span class="progress-parcent">99%</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img class="m-r-10" src="./assets/img/flags/India.png" />Brazil
                                    </td>
                                    <td>5560</td>
                                    <td>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-danger" role="progressbar" style="width:29%; height:5px;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <span class="progress-parcent">90%</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img class="m-r-10" src="./assets/img/flags/Australia.png" />Australia
                                    </td>
                                    <td>8998</td>
                                    <td>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-info" role="progressbar" style="width:58%; height:5px;" aria-valuenow="64" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <span class="progress-parcent">29%</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img class="m-r-10" src="./assets/img/flags/Singapore.png" />Singapore
                                    </td>
                                    <td>7941</td>
                                    <td>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar" role="progressbar" style="width:84%; height:5px;" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <span class="progress-parcent">33%</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img class="m-r-10" src="./assets/img/flags/uk.png" />UK
                                    </td>
                                    <td>3085</td>
                                    <td>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-info" role="progressbar" style="width:60%; height:5px;" aria-valuenow="52" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <span class="progress-parcent">86%</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <img class="m-r-10" src="./assets/img/flags/UAE.png" />UAE
                                    </td>
                                    <td>3995</td>
                                    <td>
                                        <div class="progress">
                                            <div class="progress-bar progress-bar-warning" role="progressbar" style="width:29%; height:5px;" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <span class="progress-parcent">91%</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="ibox">
                    <div class="ibox-head">
                        <div class="ibox-title">Latest Withdraw</div>
                        <div class="ibox-tools">
                            <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                            <a class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-ellipsis-v"></i></a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item">option 1</a>
                                <a class="dropdown-item">option 2</a>
                            </div>
                        </div>
                    </div>
                    <div class="ibox-body" style="overflow: hidden; overflow-x: scroll;">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>TRANS. ID</th>
                                    <th>Customer ID</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th width="91px">Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <a href="#">AT<?php echo rand('1000', '100000'); ?></a>
                                    </td>
                                    <td>#<?php echo uniqid(true); ?></td>
                                    <td>$<?php echo number_format(rand('1000', '100000')); ?></td>
                                    <td>
                                        <span class="badge badge-success">Successful</span>
                                    </td>
                                    <td><?php echo date('d/m/Y', mt_rand(strtotime(date('Y-m-d', strtotime(date('Y-m-d') . " -1 month"))), strtotime(date('Y-m-d')))); ?></td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">AT<?php echo rand('1000', '100000'); ?></a>
                                    </td>
                                    <td>#<?php echo uniqid(true); ?></td>
                                    <td>$<?php echo number_format(rand('1000', '100000')); ?></td>
                                    <td>
                                        <span class="badge badge-default">Pending</span>
                                    </td>
                                    <td><?php echo date('d/m/Y', mt_rand(strtotime(date('Y-m-d', strtotime(date('Y-m-d') . " -1 month"))), strtotime(date('Y-m-d')))); ?></td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">AT<?php echo rand('1000', '100000'); ?></a>
                                    </td>
                                    <td>#<?php echo uniqid(true); ?></td>
                                    <td>$<?php echo number_format(rand('1000', '100000')); ?></td>
                                    <td>
                                        <span class="badge badge-warning">Declined</span>
                                    </td>
                                    <td><?php echo date('d/m/Y', mt_rand(strtotime(date('Y-m-d', strtotime(date('Y-m-d') . " -1 month"))), strtotime(date('Y-m-d')))); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <style>
            .visitors-table tbody tr td:last-child {
                display: flex;
                align-items: center;
            }

            .visitors-table .progress {
                flex: 1;
            }

            .visitors-table .progress-parcent {
                text-align: right;
                margin-left: 10px;
            }
        </style>
    </div>
    <!-- END PAGE CONTENT-->
    <?php
    require_once('footer.php');
    ?>