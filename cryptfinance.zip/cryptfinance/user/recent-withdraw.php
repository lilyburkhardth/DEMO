<?php
require_once('header.php');
function random_color()
{
    $a = array("#00AFEF" => "#00AFEF", "orange" => "orange");
    if (array_rand($a, 1) !== 'orange') {
        echo '<b class="_pay_now_" style="float: left; width: 100px; text-align: center; background: #00AFEF;">PAID</b>';
    } else {
        echo '<b class="_pay_now_" style="float: left; width: 100px; text-align: center; background: orange;">PENDING</b>';
    }
}
?>
<!-- END SIDEBAR-->
<div class="content-wrapper">
    <style type="text/css">
        .tradingview-widget-copyright,
        .button-1dpg_T2E-,
        .button--right-2CEhpGhn- {
            display: none;
            height: 0px;
        }
    </style>
    <div class="tradingview-widget-container" style="background: unset !important; height: 70px !important; overflow: hidden;">
        <div class="tradingview-widget-container__widget"></div>
        <div class="tradingview-widget-copyright"><a href="#" rel="noopener" target="_blank"><span class="blue-text">Ticker Tape</span></a> by TradingView</div>
        <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
            {
                "symbols": [{
                        "title": "S&P 500",
                        "proName": "OANDA:SPX500USD"
                    },
                    {
                        "title": "Nasdaq 100",
                        "proName": "OANDA:NAS100USD"
                    },
                    {
                        "title": "EUR/USD",
                        "proName": "FX_IDC:EURUSD"
                    },
                    {
                        "title": "BTC/USD",
                        "proName": "BITSTAMP:BTCUSD"
                    },
                    {
                        "title": "ETH/USD",
                        "proName": "BITSTAMP:ETHUSD"
                    }
                ],
                "colorTheme": "dark",
                "isTransparent": true,
                "displayMode": "adaptive",
                "locale": "en"
            }
        </script>
    </div>
    <!-- START PAGE CONTENT-->
    <div class="page-heading">
        <h1 class="page-title" style="color: #FFF;">Recent Withdrawal</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php"><i class="la la-home font-20"></i></a>
            </li>
            <span style="max-width: 600px; color: #FFF;">Top investors contains all the top investors in the platform from their time of trade to their profit made on this platform. To become a top investor, upgrade your account and enjoy amazing benefits</span>
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <div class="ibox">
            <div class="ibox-head">
                <div class="ibox-title">Top Recent Witdrawals</div>
            </div>
            <div class="ibox-body table-responsive">

                <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>TRANS ID</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $array = range('1', '15');
                        foreach ($array as $arr) {
                        ?>
                            <tr>
                                <td>#<?php echo strtoupper(random_str(5)); ?></td>
                                <td>$<?php echo number_format(rand('10000', '100000')); ?></td>
                                <td><?php echo date('d/m/Y', mt_rand(strtotime(date('Y-m-d', strtotime(date('Y-m-d') . " -1 month"))), strtotime(date('Y-m-d')))); ?></td>
                                <td><?php echo random_color(); ?></td>
                            </tr>
                        <?php
                        }
                        ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- END PAGE CONTENT-->
    <?php
    require_once('footer.php');
    ?>