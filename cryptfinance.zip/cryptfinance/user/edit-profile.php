<?php
require_once('header.php');

$errors = [];
$success = [];
$show_success = $show_error = '';
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
     // Validate firstname
    if(empty(trim($_POST["full_name"]))){
        $errors[] = "Please enter your fullname.";     
    } else{
        $full_name = trim($_POST["full_name"]);
    }
    
     // Validate phone
    if(empty(trim($_POST["phone"])) && !is_numeric($_POST["phone"])){
        $errors[] = "Please enter your phone number.";     
    } else{
        $phone = trim($_POST["phone"]);
    }
        
    // Check input errors before updating the database
    if(empty($errors)){
        // Prepare an update statement
        $sql = "UPDATE users SET fullname = ?, phone = ? WHERE id = ?";
        
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("sii", $full_name, $phone, $param_id);
            
            // Set parameters
            $param_id = $_SESSION["id"];
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // profile updated successfully. Destroy the session, and redirect to login page
            
                $success[] = "Your profile has been updated successfully.";
                echo ' <meta http-equiv="refresh" content="0;url=/login.php" />';
                // header("location: /login.php");
                exit();
            } else{
                $errors[] = "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }
    
    // Close connection
    $mysqli->close();
}
if (!empty($errors)) {

    foreach ($errors as $error) {

        $show_error .= '<div class="alert alert-danger">
                <i class="fa fa-info-circle"></i> ' . $error . '
          </div>';
    }
}
if (!empty($success)) {

    foreach ($success as $suc) {

        $show_success .= '<div class="alert alert-success">
                <i class="fa fa-info-circle"></i> ' . $suc . '
          </div>';
    }
}
?>
<div class="content-wrapper">
    <style type="text/css">
        .tradingview-widget-copyright, .button-1dpg_T2E-, .button--right-2CEhpGhn-{
        display: none;
        height: 0px;
    }
    </style>
    <div class="tradingview-widget-container" style="background: unset !important; height: 70px !important; overflow: hidden;">
      <div class="tradingview-widget-container__widget"></div>
      <div class="tradingview-widget-copyright"><a href="#" rel="noopener" target="_blank"><span class="blue-text">Ticker Tape</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
          {
          "symbols": [
            {
              "title": "S&P 500",
              "proName": "OANDA:SPX500USD"
            },
            {
              "title": "Nasdaq 100",
              "proName": "OANDA:NAS100USD"
            },
            {
              "title": "EUR/USD",
              "proName": "FX_IDC:EURUSD"
            },
            {
              "title": "BTC/USD",
              "proName": "BITSTAMP:BTCUSD"
            },
            {
              "title": "ETH/USD",
              "proName": "BITSTAMP:ETHUSD"
            }
          ],
          "colorTheme": "dark",
          "isTransparent": true,
          "displayMode": "adaptive",
          "locale": "en"
        }
      </script>
    </div>
    <!-- START PAGE CONTENT-->
    <div class="page-heading">
        <h1 class="page-title" style="color: #FFF;">Update your Profile</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php"><i class="la la-home font-20"></i></a>
            </li>
            <!--<li class="breadcrumb-item">Keep your account secured by updating your password records. Do not share your password with anyone as your account details should only be used here in our platform only to enjoy maximum security from us. Thanks.</li>-->
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <div class="ibox">
            
                                    <?php
                        if (!empty($show_error)) {
                            echo $show_error;
                        }
                        ?>
                        <?php
                        if (!empty($show_success)) {
                            echo $show_success;
                        }
                        ?>
                        
            <div class="ibox-body">
                <form method="POST" action="edit-profile.php" style="max-width: 500px;">
                    <div class="form-group">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-user text-primary font-15"></i></div>
                            <input class="form-control" name="full_name" type="text" value="<?=$user_data['fullname']?>" placeholder="Full Name" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-phone text-primary font-15"></i></div>
                            <input class="form-control" name="phone" type="tel" value="<?=$user_data['phone']?>" placeholder="Phone Number" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-success" name="reset" type="submit">Update Profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
            <!-- END PAGE CONTENT-->
<?php 
require_once('footer.php');
?>