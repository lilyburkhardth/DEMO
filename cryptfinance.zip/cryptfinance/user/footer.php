            <footer class="page-footer">
                <div class="font-13"><?php echo date("Y"); ?> &copy; <b><?php echo $site_name; ?></b> - All rights reserved.</div>
                <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
            </footer>
            </div>
            </div>

            <!-- BEGIN PAGA BACKDROPS-->
            <div class="sidenav-backdrop backdrop"></div>
            <div class="preloader-backdrop">
                <div class="page-preloader">Loading</div>
            </div>
            <!-- END PAGA BACKDROPS-->
            <!-- CORE PLUGINS-->
            <script src="assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
            <script src="assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
            <script src="assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
            <script src="assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
            <script src="assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
            <!-- PAGE LEVEL PLUGINS-->
            <script src="assets/vendors/chart.js/dist/Chart.min.js" type="text/javascript"></script>
            <script src="assets/vendors/jvectormap/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
            <script src="assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
            <script src="assets/vendors/jvectormap/jquery-jvectormap-us-aea-en.js" type="text/javascript"></script>
            <!-- CORE SCRIPTS-->
            <script src="assets/js/app.min.js" type="text/javascript"></script>
            <!-- PAGE LEVEL SCRIPTS-->
            <script src="assets/js/scripts/dashboard_1_demo.js" type="text/javascript"></script>


            <!-- File Upload Preview -->
            <script src="assets/js/bootstrap-imageupload.js"></script>

            <script type="text/javascript">
                var $imageupload = $('.imageupload');
                $imageupload.imageupload({
                    allowedFormats: ['jpg', 'jpeg', 'png'],
                    maxFileSizeKb: 5096
                });
            </script>


            <script type="text/javascript">
                $(document).ready(function() {

                    $.post("https://blockchain.info/tobtc?currency=USD&value=0", function(data) {
                        $(".btc__").html(data);
                    });

                    $("._pay_now").click(function() {
                        Swal.fire({
                            html: "<center><p>All Bitcoin payments should be sent to the bitcoin address below:</p><br><b id='cWW'><?php echo $btc; ?><p></p></b><br><p>Once we confirm your payment, your account will be funded instantly.</p><br><span>For more information contact us immediately through our official email address <?php echo $support_email; ?>. Thank you for using <?php echo $site_name; ?></span><br><b class='cWA btn btn-warning btn-sm _w89'>Copy wallet address</b> <input type='text' id='cWIIT' value='<?php echo $btc; ?>'/></center>",
                            showConfirmButton: true
                        });
                        $(".cWA").click(function() {
                            copyToClipboard("#cWW");
                        })
                    })

                    $("._pprofile__").click(function() {
                        Swal.fire({
                            html: "<div style='text-align: left;'><h4>My Profile</h4><br><div><img src='assets/img/admin-avatar.png' width='65px' /><br><br>User ID: <?php echo md5($row['fullname']); ?><br>Full name: <?php echo $row['fullname']; ?><br>Country: <?php echo $row['country']; ?><br>Email: <?php echo $row['email']; ?><br>Phone number: <?php echo $row['phone']; ?><br>Account Level: <?php echo $row['level']; ?><br>Date Joined: <?php echo date('M d, Y H:i:s', strtotime($row['created_at'])); ?></div>",
                            showConfirmButton: true
                        });
                    })

                    $("._reff").each(function() {
                        $(this).click(function() {
                            Swal.fire({
                                html: "Hello <?php echo $row['fullname']; ?>, to become a referral or redeem your referral bonus, send us a message via <b><?php echo $support_email; ?></b> or contact our live chat team to redeem your referral bonus.<br><br><div class='alert alert-info alert-bordered' style='font-size: 14px !important;'>For more information contact us immediately through our official email address <?php echo $support_email; ?>. Thanks for choosing <?php echo $site_name; ?></div>",
                                showConfirmButton: true
                            });

                        })
                    })

                    $("._upgrade_").each(function() {
                        $(this).click(function() {
                            var _amount_ = $(this).attr("amt");
                            var pck = $(this).attr("pck");
                            Swal.fire({
                                html: "Hello <?php echo $row['fullname']; ?>, to upgrade your <?php echo $site_name; ?> trading account to <b>" + pck + "</b>, please contact our Live Chat agent to receive the appropriate payment details. Alternatively, you can contact your Account Manager to help you with the account upgrade. <b>$" + (_amount_) + ".00</b><br><br><div class='alert alert-info alert-bordered' style='font-size: 14px !important;'>For more information contact us immediately through our official email address <?php echo $support_email; ?>. Thanks for using <?php echo $site_name; ?></div>",
                                showConfirmButton: true
                            });

                        })
                    });

                    $("._oDp").each(function() {
                        var _ooo = $(this).attr("id");
                        $(this).click(function() {
                            PushN(_ooo + " Deposit", "<p>If you wish to fund your SuperiorTradeOption account via <b>" + _ooo + "</b>, please contact our Live Chat agent to receive the appropriate payment details. Alternatively, you can contact your Account Manager to help you fund your account.</p><br><p class='_npane__'>For more information contact us immediately through our official email address support@superiortradeoption.com Thanks for choosing SuperiorTradeOption</p>", 1);
                        });
                    });

                })

                function PushN(title_, message, close_) {

                    $("._mod_head").html(title_);
                    $("._mod_text").html(message);

                    if (close_ === 0) {
                        $("._mod_close").hide(0);
                    }

                    $("._npane").show(0, function() {
                        $("._npane").fadeIn(700);
                        $("._mod_close").click(function() {
                            $("._npane").fadeOut(200, function() {
                                $("._npane").hide(0);
                            });
                        });
                    });
                }

                function copyToClipboard(element) {
                    var $temp = $("<input>");
                    $("body").append($temp);
                    $temp.val($(element).text()).select();
                    document.execCommand("copy");
                    $temp.remove();

                    /* Alert the copied text */
                    Swal.fire({
                        icon: 'success',
                        html: "<b>" + $(element).text() + "</b><br><br> <b style='color: red;'>Copied!</b>",
                        showConfirmButton: true,
                        timer: 2500
                    });
                }
                $("#withdrawalMethod").change(function() {
                    if ($(this).val() == "Bitcoin" || $(this).val() == "Ethereum" || $(this).val() == "Ripple" || $(this).val() == "Bitcoin Cash" || $(this).val() == "EOS." || $(this).val() == "Cardano" || $(this).val() == "Litecoin" || $(this).val() == "Stellar") {
                        $("#beneficiaryField1").fadeIn();
                        $("#beneficiaryField2").hide();
                        $("#beneficiaryField3").hide();
                        $("#beneficiaryField4").hide();
                        $("#beneficiaryField5").hide();
                        $("#beneficiaryField6").hide();
                    } else if ($(this).val() == "PayPal") {
                        $("#beneficiaryField2").fadeIn();
                        $("#beneficiaryField1").hide();
                        $("#beneficiaryField3").hide();
                        $("#beneficiaryField4").hide();
                        $("#beneficiaryField5").hide();
                        $("#beneficiaryField6").hide();
                    } else if ($(this).val() == "Bank Transfer") {
                        $("#beneficiaryField3").fadeIn();
                        $("#beneficiaryField4").fadeIn();
                        $("#beneficiaryField5").fadeIn();
                        $("#beneficiaryField6").fadeIn();
                        $("#beneficiaryField1").hide();
                        $("#beneficiaryField2").hide();
                    } else {
                        $("#beneficiaryField1").hide();
                        $("#beneficiaryField2").hide();
                        $("#beneficiaryField3").hide();
                        $("#beneficiaryField4").hide();
                        $("#beneficiaryField5").hide();
                        $("#beneficiaryField6").hide();
                    }
                });
            </script>
            
            <script src="//code.tidio.co/q4tbmzmfp7h7mkb3rztywtvtiyrquv59.js" async></script>
            </body> 

            </html>