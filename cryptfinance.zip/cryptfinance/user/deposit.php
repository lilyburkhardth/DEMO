<?php
require_once('header.php');
$amount = '';
$show_pop = false;
if (isset($_POST['deposit'])) {
    $user_id = $row['id'];
    $payment_gateway = htmlspecialchars($_POST['payment_gateway']);
    $amount = htmlspecialchars($_POST['amount']);
    $reference = random_str(16);
    $sql = "INSERT INTO deposit (user_id, reference, payment_method, amount)
VALUES ('$user_id', '$reference', '$payment_gateway', '$amount')";
    if ($mysqli->query($sql) === TRUE) {
        $show_pop = true;
    } else {
    }
}
?>
<!-- END SIDEBAR-->
<div class="content-wrapper">
    <!-- START PAGE CONTENT-->
    <div class="page-heading">
        <h1 class="page-title" style="color: #FFF;">Fund Account</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php"><i class="la la-home font-20"></i></a>
            </li>
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <div class="ibox" style="background: #1d1d1d !important; padding: 0px !important;">
            <div class="ibox-body clearfix" style="padding: 0px !important;">
                <div class="_seg_pay">
                    <h4 class="_phh">Bitcoin</h4>
                    <center><img class="_seg_pay_img_" src="images/bitcoin.png"></center>
                    <div class="_gwAA _nnp_btn" data-toggle="modal" data-target="#pay_btc" style="border-radius: 3px;">Deposit</div>
                </div>

                <div class="_seg_pay">
                    <h4 class="_phh">USDT trc20</h4>
                    <center><img class="_seg_pay_img_" src="images/usdt.png"></center>
                    <div class="_gwAA _nnp_btn" data-toggle="modal" data-target="#pay_usdt">Deposit</div>
                </div>

            </div>
        </div>
    </div>

    <div class="page-content fade-in-up">
        <div class="ibox">
            <div class="ibox-head">
                <div class="ibox-title">My Deposit History</div>
            </div>
            <div class="ibox-body table-responsive">
                <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Reference</th>
                            <th>Payment Method</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql_deposit = "SELECT * FROM deposit WHERE user_id='$current_user_id' ORDER BY id DESC";
                        $deposit_result = $mysqli->query($sql_deposit);
                        if ($deposit_result->num_rows > 0) {
                            $i = 1;
                            while ($deposit_row = $deposit_result->fetch_assoc()) {
                        ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo strtoupper($deposit_row['reference']); ?></td>
                                    <td><?php echo $deposit_row['payment_method']; ?></td>
                                    <td>$<?php echo number_format($deposit_row['amount']); ?></td>
                                    <td><?php echo date('M d, Y H:i:s', strtotime($deposit_row['date'])); ?></td>
                                    <td>
                                        <?php
                                        if ($deposit_row['status'] === '0') {
                                        ?>
                                            <span class="_pay_now label label-warning">PENDING</span>
                                        <?php
                                        } else {
                                        ?>
                                            <span class="label label-success">SUCCESSFUL</span>
                                        <?php
                                        }
                                        ?>
                                </tr>
                        <?php
                                $i++;
                            }
                        }
                        ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- END PAGE CONTENT-->
    <?php if (!empty($show_pop)) { ?>
        <script>
            Swal.fire(
                "Deposit Requested",
                "Your deposit request of $<?php echo number_format($amount); ?> was successful. You account will be funded once we verify your payment. Thanks for choosing <?php echo $site_name; ?>",
                "success"
            );
        </script>
    <?php } ?>

    <!-- BEGIN PAGA BACKDROPS-->
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader"></div>
    </div>
    <!-- END PAGA BACKDROPS-->

    <div class="modal fade" id="pay_btc">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">BITCOIN DEPOSIT</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <p>All Bitcoin payments should be sent to the bitcoin address below:</p>
                    <center>
                        <img src="https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl=bitcoin:<?php echo $btc; ?>" />
                    </center>

                    <div class="input-group mb-20">
                         <input style="width: 100%; padding-left: 20px; font-weight: bold;" type="text" value="<?php echo $btc; ?>" id="myInput" readonly="readonly">
                            <button onclick="myFunction(); this.innerHTML='Copied'; this.classList.remove('btn-success');this.classList.add('btn-warning');" class="btn btn-success btc-button" type="button">Copy</button>
                    </div>
                    
                    
                    
<script>
function myFunction() {
  /* Get the text field */
  var copyText = document.getElementById("myInput");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

  /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);
  
}
</script>
                    

                    <form method="post" action="deposit.php">

                        <input type="hidden" name="user_id" value="<?php echo $current_user_id; ?>">
                        <input type="hidden" name="payment_gateway" value="Bitcoin">

                        <div class="form-group mt-3">
                            <label for="deposit_amount">Amount Paid</label>
                            <input type="number" class="form-control" name="amount" placeholder="0.00" required>
                        </div>

                        <button type="submit" name="deposit" class="btn btn-info btn-block"><i class="fa fa-money"></i> Confirm Deposit</button>
                    </form>

                    <br>
                    <p>Once we confirm your payment, your account will be funded instantly.</p>
                    <span>For more information contact us immediately through our official email address <?php echo $support_email; ?>. Thanks for choosing <?php echo $site_name; ?></span>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="pay_usdt">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">USDT trc20 DEPOSIT</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <p>All USDT trc20 payments should be sent to the USDT trc20 address below:</p>

                    <center>
                        <img src="https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl=usdt:<?php echo $usdt; ?>" />
                    </center>

                    <div class="input-group mb-20">
                         <input style="width: 100%; padding-left: 20px; font-weight: bold;" type="text" value="<?php echo $usdt; ?>" id="usdtcopy" readonly="readonly">
                            <button onclick="myFunctions(); this.innerHTML='Copied'; this.classList.remove('btn-success');this.classList.add('btn-warning');" class="btn btn-success btc-button" type="button">Copy</button>
                    </div>
                    
                    
<script>
function myFunctions() {
  /* Get the text field */
  var copyText = document.getElementById("usdtcopy");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

  /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);
  
}
</script>
                    
                    

                    <form method="post" action="deposit.php">

                        <input type="hidden" name="user_id" value="<?php echo $current_user_id; ?>">
                        <input type="hidden" name="payment_gateway" value="Ethereum">

                        <div class="form-group mt-3">
                            <label for="deposit_amount">Amount Paid</label>
                            <input type="number" class="form-control" name="amount" placeholder="0.00" required>
                        </div>

                        <button type="submit" name="deposit" class="btn btn-info btn-block"><i class="fa fa-money"></i> Confirm Deposit</button>
                    </form>

                    <br>
                    <p>Once we confirm your payment, your account will be funded instantly.</p>
                    <span>For more information contact us immediately through our official email address <?php echo $support_email; ?>. Thanks for choosing <?php echo $site_name; ?></span>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
    <?php
    require_once('footer.php');
    ?>