<?php
require_once('header.php');
 
// Define variables and initialize with empty values
$new_password = $confirm_password = "";

$errors = [];
$success = [];
$show_success = $show_error = '';
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate new password
    if(empty(trim($_POST["new_password"]))){
        $errors[] = "Please enter the new password.";     
    } elseif(strlen(trim($_POST["new_password"])) < 6){
        $errors[] = "Password must have atleast 6 characters.";
    } else{
        $new_password = trim($_POST["new_password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $errors[] = "Please confirm the password.";
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($errors) && ($new_password != $confirm_password)){
            $errors[] = "Password did not match.";
        }
    }
        
    // Check input errors before updating the database
    if(empty($new_password_err) && empty($confirm_password_err)){
        // Prepare an update statement
        $sql = "UPDATE users SET password = ? WHERE id = ?";
        
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("si", $param_password, $param_id);
            
            // Set parameters
            $param_password = password_hash($new_password, PASSWORD_DEFAULT);
            $param_id = $_SESSION["id"];
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Password updated successfully. Destroy the session, and redirect to login page
                session_destroy();
                $success[] = "Your password has been changed successfully.";
                echo ' <meta http-equiv="refresh" content="0;url=/login.php" />';
                // header("location: /login.php");
                exit();
            } else{
                $errors[] = "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }
    
    // Close connection
    $mysqli->close();
}
if (!empty($errors)) {

    foreach ($errors as $error) {

        $show_error .= '<div class="alert alert-danger">
                <i class="fa fa-info-circle"></i> ' . $error . '
          </div>';
    }
}
if (!empty($success)) {

    foreach ($success as $suc) {

        $show_success .= '<div class="alert alert-success">
                <i class="fa fa-info-circle"></i> ' . $suc . '
          </div>';
    }
}
?>
<div class="content-wrapper">
    <style type="text/css">
        .tradingview-widget-copyright, .button-1dpg_T2E-, .button--right-2CEhpGhn-{
        display: none;
        height: 0px;
    }
    </style>
    <div class="tradingview-widget-container" style="background: unset !important; height: 70px !important; overflow: hidden;">
      <div class="tradingview-widget-container__widget"></div>
      <div class="tradingview-widget-copyright"><a href="#" rel="noopener" target="_blank"><span class="blue-text">Ticker Tape</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
          {
          "symbols": [
            {
              "title": "S&P 500",
              "proName": "OANDA:SPX500USD"
            },
            {
              "title": "Nasdaq 100",
              "proName": "OANDA:NAS100USD"
            },
            {
              "title": "EUR/USD",
              "proName": "FX_IDC:EURUSD"
            },
            {
              "title": "BTC/USD",
              "proName": "BITSTAMP:BTCUSD"
            },
            {
              "title": "ETH/USD",
              "proName": "BITSTAMP:ETHUSD"
            }
          ],
          "colorTheme": "dark",
          "isTransparent": true,
          "displayMode": "adaptive",
          "locale": "en"
        }
      </script>
    </div>
    <!-- START PAGE CONTENT-->
    <div class="page-heading">
        <h1 class="page-title" style="color: #FFF;">Update your Password</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php"><i class="la la-home font-20"></i></a>
            </li>
            <li class="breadcrumb-item">Keep your account secured by updating your password records. Do not share your password with anyone as your account details should only be used here in our platform only to enjoy maximum security from us. Thanks.</li>
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <div class="ibox">
            
                                    <?php
                        if (!empty($show_error)) {
                            echo $show_error;
                        }
                        ?>
                        <?php
                        if (!empty($show_success)) {
                            echo $show_success;
                        }
                        ?>
                        
            <div class="ibox-body">
                <form method="POST" action="update-password.php" style="max-width: 500px;">
                    <div class="form-group">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-lock text-primary font-15"></i></div>
                            <input class="form-control" name="new_password" type="password" placeholder="New Password" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-lock text-primary font-15"></i></div>
                            <input class="form-control" type="password" name="confirm_password" placeholder="Re-type New Password" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-success" name="reset" type="submit">Change Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
            <!-- END PAGE CONTENT-->
<?php 
require_once('footer.php');
?>