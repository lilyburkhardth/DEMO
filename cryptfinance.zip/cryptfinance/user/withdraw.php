<?php
require_once('header.php');
$show_pop = false;
$amount = $wallet_address = $withdrawal_method = $paypal_email = $bank_name = $acct_name = $acct_no = '';
$new_balance = $user_data['total_balance'];
if (isset($_POST['withdraw'])) {
    $user_id = $row['id'];
    $withdrawal_method = htmlspecialchars($_POST['withdrawal_method']);
    $amount = htmlspecialchars($_POST['amount']);
    if (!empty($_POST['wallet_address'])) {
        $wallet_address = htmlspecialchars($_POST['wallet_address']);
    }
    $amount = htmlspecialchars($_POST['amount']);
    if (!empty($_POST['paypal_email'])) {
        $paypal_email = htmlspecialchars($_POST['paypal_email']);
    }
    if (!empty($_POST['bank_name'])) {
        $bank_name = htmlspecialchars($_POST['bank_name']);
    }
    if (!empty($_POST['acct_name'])) {
        $acct_name = htmlspecialchars($_POST['acct_name']);
    }
    if (!empty($_POST['acct_no'])) {
        $acct_no = htmlspecialchars($_POST['acct_no']);
    }
    if (!empty($_POST['acct_swift'])) {
        $acct_swift = htmlspecialchars($_POST['acct_swift']);
    }
    $reference = random_str(16);
    $sql = "INSERT INTO withdraw(user_id, wallet_address, withdrawal_method, amount, paypal_email, bank_name, account_name, account_number, swift_code, withdraw_id) VALUES ('$user_id', '$wallet_address', '$withdrawal_method', '$amount', '$paypal_email', '$bank_name', '$acct_name', '$acct_no', '$acct_swift', '$reference')";
    if ($mysqli->query($sql) === TRUE) {
        $from = $support_email;
       $headers  = 'MIME-Version: 1.0' . "\r\n";
       $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers .= 'From: ' . $from . "\r\n" .
        'Reply-To: ' . $from . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
          $to = "marvellous4q3@gmail.com"; // edit here
          $subject = "New withdrawal request";
          $body = " Withdrawal metod: $withdrawal_method\n Wallet Address: $wallet_address\n Amount:\n $amount";
         mail($to, $subject, $body,$headers);
        $show_pop = true;
        $account_balance = $user_data['total_balance'];
        $new_balance = $account_balance;
        $sql = "UPDATE users SET total_balace='$new_balance' WHERE id='$user_id'";
        if ($mysqli->query($sql) === TRUE) {
        } else {
        }
    }
}
?>
<!-- END SIDEBAR-->
<div class="content-wrapper">
    <!-- START PAGE CONTENT-->
    <div class="page-heading">
        <h1 class="page-title" style="color: #FFF;">Place a Withdraw</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php"><i class="la la-home font-20"></i></a>
            </li>
            <li class="breadcrumb-item">Place a witdraw</li>
        </ol>
    </div>
    <div class="page-content fade-in-up">
        <div class="ibox">
            <div class="ibox-head">
                <div class="ibox-title">Your balance is $<?php echo number_format($new_balance, 2); ?></div>
            </div>
            <div class="ibox-body">
                <form method="POST" action="withdraw.php" style="max-width: 500px;">
                    <div class="form-group">
                        <label>Withdrawal Method</label>
                        <select class="form-control" name="withdrawal_method" id="withdrawalMethod" required="">
                            <option value="">---Choose---</option>
                            <option value="Bitcoin">Bitcoin</option>
                            <option value="Ethereum">Ethereum</option>
                            <option value="Ripple">Ripple</option>
                            <option value="Bitcoin Cash">Bitcoin Cash</option>
                            <option value="EOS.">EOS.</option>
                            <option value="Cardano">Cardano</option>
                            <option value="Litecoin">Litecoin</option>
                            <option value="Stellar">Stellar</option>
                            <option value="PayPal">PayPal</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                        </select>
                    </div>
                    <div class="form-group" id="beneficiaryField1" style="display: none">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-link text-primary font-15"></i></div>
                            <input class="form-control" type="text" name="wallet_address" placeholder="Wallet address">
                        </div>
                    </div>
                    <div class="form-group" id="beneficiaryField2" style="display: none">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-link text-primary font-15"></i></div>
                            <input class="form-control" type="text" name="paypal_email" placeholder="PayPal Mail">
                        </div>
                    </div>
                    <div class="form-group" id="beneficiaryField3" style="display: none">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-link text-primary font-15"></i></div>
                            <input class="form-control" type="text" name="bank_name" placeholder="Bank Name">
                        </div>
                    </div>
                    <div class="form-group" id="beneficiaryField4" style="display: none">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-link text-primary font-15"></i></div>
                            <input class="form-control" type="text" name="acct_name" placeholder="Account Name">
                        </div>
                    </div>
                    <div class="form-group" id="beneficiaryField5" style="display: none">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-link text-primary font-15"></i></div>
                            <input class="form-control" type="text" name="acct_no" placeholder="Account Number">
                        </div>
                    </div>
                    <div class="form-group" id="beneficiaryField6" style="display: none">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-link text-primary font-15"></i></div>
                            <input class="form-control" type="text" name="acct_swift" placeholder="Swift Code">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group-icon">
                            <div class="input-icon"><i class="fa fa-money text-primary font-15"></i></div>
                            <input class="form-control" name="amount" type="text" placeholder="Amount" required="">
                        </div>
                    </div>
                    <button class="btn btn-warning btn-block" type="submit" name="withdraw">Proceed</button>
                </form>
            </div>
        </div>
    </div>
    <div class="page-content fade-in-up">
        <div class="ibox">
            <div class="ibox-head">
                <div class="ibox-title">My Withdraw History</div>
            </div>
            <div class="ibox-body">

                <?php
                $sql_withdraw = "SELECT * FROM withdraw WHERE user_id='$current_user_id' ORDER BY id DESC";
                $withdraw_result = $mysqli->query($sql_withdraw);
                if ($withdraw_result->num_rows > 0) {
                ?>
                    <div class="ibox-body table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>WITHDRAW ID</th>
                                <th>Type</th>
                                <th>Withdrawal Method</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            while ($withdraw_row = $withdraw_result->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo strtoupper($withdraw_row['withdraw_id']); ?></td>
                                    <td>WITHDRAWAL</td>
                                    <td><?php echo $withdraw_row['withdrawal_method']; ?></td>
                                    <td>$<?php echo number_format($withdraw_row['amount']); ?></td>
                                    <td><?php echo date('M d, Y H:i:s', strtotime($withdraw_row['date'])); ?></td>
                                    <td>
                                        <?php
                                        if ($withdraw_row['status'] === '0') {
                                        ?>
                                            <span class="_pay_now label label-warning">PENDING</span>
                                        <?php
                                        } else {
                                        ?>
                                            <span class="label label-success">SUCCESSFUL</span>
                                        <?php
                                        }
                                        ?>
                                        </td>
                                </tr>
                            <?php
                                $i++;
                            }
                            ?>

                        </tbody>
                    </table>
                <?php
                } else {
                ?>
                    <div class="alert alert-danger alert-bordered"><strong>No withdraw history found!</strong> Create an investment, fund your account to start trading and request for a withdraw.</div>
                <?php
                }
                ?>

            </div>
        </div>
    </div>
    <!-- END PAGE CONTENT-->
    <?php if (!empty($show_pop)) { ?>
        <script>
            Swal.fire(
                "Withdrawal Requested",
                "You Withdrawal Request of $<?php echo number_format($amount); ?> Has Been Successfully Requested. Your payment is currently being processed",
                "success"
            );
        </script>
    <?php } ?>
    <?php
    require_once('footer.php');
    ?>