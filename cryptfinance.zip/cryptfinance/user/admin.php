<?php
require_once('header.php');
if ($user_data['role'] !== '1') {
    die('Not alllowed.');
}

function get_userdata($id, $value)
{
    global $mysqli;
    $sql = "SELECT * FROM users WHERE id='$id'";
    $result = $mysqli->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row["$value"];
    } else {
        return 'Unknown';
    }
}

$errors = [];
$success = [];
$email = $password = "";
$show_success = $show_error = '';

if (isset($_GET['delete']) && $_GET['type'] === 'users' && !empty($_GET['id'])) {
    $_user_id = htmlspecialchars($_GET['id']);
    $sql = "DELETE FROM users WHERE id='$_user_id'";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "User deleted successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error deleting user";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_POST['update_balance']) && !empty($_POST['id'])) {
    $_user_id = htmlentities($_POST['id']);
    $_invested = htmlentities($_POST['invested']);
    $_balance = htmlentities($_POST['balance']);
    $_bonus = htmlentities($_POST['bonus']);
    $_level = htmlentities($_POST['level']);
    $_deposit = htmlentities($_POST['deposit']);
    if (!ctype_digit($_user_id)) die();
    $sql = "UPDATE users SET balance='$_invested', total_balance='$_balance', level='$_level', bonus='$_bonus', deposit='$_deposit' WHERE id='$_user_id'";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "User balance updated successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error updating the user balance";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_GET['delete']) && $_GET['type'] === 'withdraw' && !empty($_GET['id'])) {
    $_id = htmlspecialchars($_GET['id']);
    $sql = "DELETE FROM withdraw WHERE id='$_id'";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "Withdraw request deleted successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error deleting Withdraw request";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_GET['approve']) && $_GET['type'] === 'withdraw' && !empty($_GET['id'])) {
    $_id = htmlspecialchars($_GET['id']);
    if (!ctype_digit($_id)) die();
    $sql = "UPDATE withdraw SET status='1' WHERE id='$_id';";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "Withdraw approved successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
        $mysqli->next_result();
    } else {
        $errors[] = "Error approving withdraw";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_GET['delete']) && $_GET['type'] === 'deposit' && !empty($_GET['id'])) {
    $_id = htmlspecialchars($_GET['id']);
    $sql = "DELETE FROM deposit WHERE id='$_id'";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "Deposit request deleted successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error deleting Deposit request";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_GET['approve']) && $_GET['type'] === 'deposit' && !empty($_GET['id'])) {
    $_id = htmlspecialchars($_GET['id']);
    $_amount = htmlspecialchars($_GET['amount']);
    $_user_id = htmlspecialchars($_GET['user_id']);
    if (!ctype_digit($_id)) die();
    $balance = '';
    $sql = "SELECT * FROM users WHERE id='$_user_id'";
    $result = $mysqli->query($sql);
    if ($result->num_rows > 0) {
        $approve_row = $result->fetch_assoc();
        $balance = $approve_row['balance'];
    } else {
        $errors[] = "Oops! Something went wrong.";
    }
    $new_balance = $balance + intval($_amount);
    $sql = "UPDATE deposit SET status='1' WHERE id='$_id';";
    $sql .= "UPDATE users SET balance='$new_balance', total_balance='$new_balance' WHERE id='$_user_id'";
    if ($mysqli->multi_query($sql) === TRUE) {
        $success[] = "Deposit approved successfully";
        $mysqli->next_result();
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error approving deposit";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (!empty($errors)) {

    foreach ($errors as $error) {

        $show_error .= '<div class="alert alert-danger">
                <i class="fa fa-info-circle"></i> ' . $error . '
          </div>';
    }
}
if (!empty($success)) {

    foreach ($success as $suc) {

        $show_success .= '<div class="alert alert-success">
                <i class="fa fa-info-circle"></i> ' . $suc . '
          </div>';
    }
}

?>
<div class="content-wrapper">

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand">Admin</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="admin.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?show=users">Users</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?show=withdrawal_management">Withdrawal management</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?show=deposit_management">Deposit management</a>
                </li>
            </ul>
        </div>
    </nav>

    <?php
    if (!empty($show_error)) {
        echo $show_error;
    }
    ?>
    <?php
    if (!empty($show_success)) {
        echo $show_success;
    }
    ?>

    <?php
    if (!isset($_GET['show']) || $_GET['show'] === 'users') {
    ?>
        <div class="page-content fade-in-up">


            <?php if (isset($_GET['edit']) && $_GET['type'] === 'users' && !empty($_GET['id'])) {

            ?>

                <div class="ibox">
                    <div class="ibox-head">
                        <?php
                        $_user_id = htmlspecialchars($_GET['id']);
                        $sql = "SELECT * FROM users WHERE id='$_user_id'";
                        $result = $mysqli->query($sql);
                        if ($result->num_rows > 0) {
                            $_user_Data = $result->fetch_assoc();
                            $_fullname = $_user_Data['fullname'];
                        } else {
                            $_fullname = '';
                        }
                        ?>
                        <div class="ibox-title">Change <?php echo $_fullname; ?> balance</div>
                    </div>
                    <div class="ibox-body">
                        <form method="POST" style="max-width: 500px;">
                            <input class="form-control" name="id" type="hidden" value="<?php echo $_user_id; ?>" required="">
                                <div class="form-group">
                                    <label>Level</label>
                                <select class="form-control" name="level">
                                    <option value="STARTER" <?php if($_user_Data['level'] == 'STARTER'){echo 'selected';}?>>
                                        STARTER
                                    </option>
                                      <option value="BRONZE" <?php if($_user_Data['level'] == 'BRONZE'){echo 'selected';}?>>
                                        BRONZE
                                    </option>
                                      <option value="SILVER" <?php if($_user_Data['level'] == 'SILVER'){echo 'selected';}?>>
                                        SILVER
                                    </option>
                                      <option value="DIAMOND" <?php if($_user_Data['level'] == 'DIAMOND'){echo 'selected';}?>>
                                        DIAMOND
                                    </option>
                                      <option value="GOLD" <?php if($_user_Data['level'] == 'GOLD'){echo 'selected';}?>>
                                        GOLD
                                    </option>
                                </select>
                            </div>  
                            <div class="form-group">
                                <input class="form-control" name="invested" type="text" placeholder="Invested" value="<?php echo $_user_Data['balance']; ?>" required="">

                            </div>

                            <div class="form-group">
                                <input class="form-control" name="balance" type="text" placeholder="Balance" value="<?php echo $_user_Data['total_balance']; ?>" required="">

                            </div>
                            
                            <div class="form-group">
                                <input class="form-control" name="bonus" type="text" placeholder="Bonus" value="<?php echo $_user_Data['bonus']; ?>" required="">

                            </div>
                            
                            <div> 
                            <input class="form-control" name="deposit" type="text" place holder="Deposit" value="<?php echo $_user_Data['deposit']; ?>" required="">
                            
                            </div>

                            <button class="btn btn-warning btn-block" type="submit" name="update_balance">Update</button>
                        </form>
                    </div>
                </div>


            <?php
            }
            ?>

            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Users</div>
                </div>
                <div class="ibox-body table-responsive">

                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Email</th>
                                <th>Joined</th>
                                <th>Full name</th>
                                <th>Phone</th>
                                <th>Level</th>
                                <th>Gender</th>
                                <th>Country</th>
                                <th>Invested</th>
                                <th>Balance</th>
                                <th>bonus</th>
                                <th>deposit</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            $sql = "SELECT * FROM users ORDER BY id DESC";
                            $result = $mysqli->query($sql);

                            if ($result->num_rows > 0) {

                                while ($user_row = $result->fetch_assoc()) {
                            ?>
                                    <tr>
                                        <td><?php echo $user_row["id"]; ?></td>
                                        <td><?php echo $user_row["email"]; ?></td>
                                        <td><?php echo date('M d, Y H:i:s', strtotime($user_row['created_at'])); ?></td>
                                        <td><?php echo $user_row["fullname"]; ?></td>
                                        <td><?php echo $user_row["phone"]; ?></td>
                                        <td><?php echo $user_row["level"]; ?></td>
                                        <td><?php echo $user_row["gender"]; ?></td>
                                        <td><?php echo $user_row["country"]; ?></td>
                                        <td><?php echo $user_row["balance"]; ?></td>
                                        <td><?php echo $user_row["bonus"];?></td>
                                        <td><?php echo $user_row["deposit"];?></td>
                                        <td><?php echo $user_row["total_balance"]; ?></td>
                                        <td><a href="?delete=true&type=users&id=<?php echo $user_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a> &bull; <a href="?edit=true&type=users&id=<?php echo $user_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-edit"></i></a></td>
                                    </tr>
                            <?php
                                }
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php } ?>
    <!-- #Users -->

    <?php
    if (!isset($_GET['show']) || $_GET['show'] === 'withdrawal_management') {
    ?>

        <div class="page-content fade-in-up">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Withdrawal Management</div>
                </div>
                <div class="ibox-body table-responsive">
                <div class="ibox-body">

                    <?php
                    $sql_withdraw = "SELECT * FROM withdraw ORDER BY id DESC";
                    $withdraw_result = $mysqli->query($sql_withdraw);
                    if ($withdraw_result->num_rows > 0) {
                    ?>
                        <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>WITHDRAW ID</th>
                                    <th>Full name</th>
                                    <th>Type</th>
                                    <th>Withdrawal Method</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                while ($withdraw_row = $withdraw_result->fetch_assoc()) {
                                ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo strtoupper($withdraw_row['withdraw_id']); ?></td>
                                        <td><?php echo get_userdata($withdraw_row["user_id"], 'fullname'); ?></td>
                                        <td>WITHDRAWAL</td>
                                        <td><?php echo $withdraw_row['withdrawal_method']; ?></td>
                                        <td>$<?php echo number_format($withdraw_row['amount']); ?></td>
                                        <td><?php echo date('M d, Y H:i:s', strtotime($withdraw_row['date'])); ?></td>
                                        <td>
                                            <?php
                                            if ($withdraw_row['status'] === '0') {
                                            ?>
                                                <span class="_pay_now label label-warning">PENDING</span>
                                            <?php
                                            } else {
                                            ?>
                                                <span class="label label-success">SUCCESSFUL</span>
                                            <?php
                                            }
                                            ?>
                                        </td>
                                        <td><a href="?delete=true&type=withdraw&id=<?php echo $withdraw_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a> &bull; <a href="?approve=true&type=withdraw&id=<?php echo $withdraw_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-check"></i></a></td>
                                    </tr>
                                <?php
                                    $i++;
                                }
                                ?>

                            </tbody>
                        </table>
                    <?php
                    } else {
                    ?>
                        <div class="alert alert-danger alert-bordered"><strong>No withdraw history found!</strong></div>
                    <?php
                    }
                    ?>

                </div>
            </div>
        </div>
    <?php
    }
    ?>
    <!-- #withdraw -->

    <?php
    if (!isset($_GET['show']) || $_GET['show'] === 'deposit_management') {
    ?>

        <div class="page-content fade-in-up">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Deposit Management</div>
                </div>
                <div class="ibox-body table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Reference</th>
                                <th>Full name</th>
                                <th>Payment Method</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql_deposit = "SELECT * FROM deposit ORDER BY id DESC";
                            $deposit_result = $mysqli->query($sql_deposit);
                            if ($deposit_result->num_rows > 0) {
                                $i = 1;
                                while ($deposit_row = $deposit_result->fetch_assoc()) {
                            ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo strtoupper($deposit_row['reference']); ?></td>
                                        <td><?php echo get_userdata($deposit_row["user_id"], 'fullname'); ?></td>
                                        <td><?php echo $deposit_row['payment_method']; ?></td>
                                        <td>$<?php echo number_format($deposit_row['amount']); ?></td>
                                        <td><?php echo date('M d, Y H:i:s', strtotime($deposit_row['date'])); ?></td>
                                        <td>
                                            <?php
                                            if ($deposit_row['status'] === '0') {
                                            ?>
                                                <span class="_pay_now label label-warning">PENDING</span>
                                            <?php
                                            } else {
                                            ?>
                                                <span class="label label-success">SUCCESSFUL</span>
                                            <?php
                                            }
                                            ?>
                                        </td>
                                        <td><a href="?delete=true&type=deposit&id=<?php echo $deposit_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a> &bull; <a href="?approve=true&type=deposit&id=<?php echo $deposit_row["id"]; ?>&amount=<?php echo $deposit_row['amount']; ?>&user_id=<?php echo $deposit_row["user_id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-check"></i></a></td>
                                    </tr>
                            <?php
                                    $i++;
                                }
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <?php } ?>

</div>
<?php
require_once('footer.php');
?>