<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.cryptfinanceinvest.com/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 Dec 2023 13:55:29 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <title>Crypto Finance Investment - Forex, Stocks, ETFs & Options Trading</title>
    <meta name="title" content="Crypto Finance Investment - Forex, Stocks, ETFs & Options Trading">
    <meta name="description" content="Trade stocks, ETFs, forex &amp; Digital Options at Crypto Finance Investment, one of the fastest growing online trading platforms. Sign up today and be a part of 17 million user base at Crypto Finance Investment.">
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="index.php">
    <meta property="og:title" content="Crypto Finance Investment - Forex, Stocks, ETFs & Options Trading">
    <meta property="og:description" content="Trade stocks, ETFs, forex &amp; Digital Options at Crypto Finance Investment, one of the fastest growing online trading platforms. Sign up today and be a part of 17 million user base at Crypto Finance Investment">
    <meta property="og:image" content="img/BITCOIN.jpg">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="index.php">
    <meta property="twitter:title" content="Crypto Finance Investment - Forex, Stocks, ETFs & Options Trading">
    <meta property="twitter:description" content="Trade stocks, ETFs, forex &amp; Digital Options at Crypto Finance Investment, one of the fastest growing online trading platforms. Sign up today and be a part of 17 million user base at Crypto Finance Investment">
    <meta property="twitter:image" content="img/BITCOIN.jpg">
    <!-- [if lt IE 9]>
        <script src="js/html5shiv.min.js"></script>
        <script src="js/respond.min.js"></script>
    <![endif] -->
    <link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="public/css/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="public/css/flaticon.min.css">
    <link rel="stylesheet" type="text/css" href="public/css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="public/css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="public/css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="public/css/magnific-popup.min.css">
    <link rel="stylesheet" type="text/css" href="public/css/loader.min.css">
    <link rel="stylesheet" type="text/css" href="public/css/style23562356.css?74719">
    <link rel="stylesheet" class="skin" type="text/css" href="public/css/skin/skin-2f29ff29f.css?28900">
    <link rel="stylesheet" type="text/css" href="public/css/custom.html">
    <link rel="stylesheet" type="text/css" href="public/plugins/revolution/revolution/css/settings.css">
    <link rel="stylesheet" type="text/css" href="public/plugins/revolution/revolution/cs/navigation.d.txt">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
    <style>
        .mgm {
            border-radius: 7px;
            position: fixed;
            z-index: 90;
            bottom: 45%;
            right: 50px;
            background: #fff;
            padding: 10px 27px;
            box-shadow: 0px 5px 13px 0px rgba(0, 0, 0, .3);
        }

        .mgm a {
            font-weight: 700;
            display: block;
            color: #8BC34A;
        }

        .mgm a,
        .mgm a:active {
            transition: all .2s ease;
            color: #8BC34A;
        }
    </style>
</head>
<body>
    
    <!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+15408357251", // WhatsApp number
            call_to_action: "Message us", // Call to action
            button_color: "#FF6550", // Color of button
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = 'https:', host = "getbutton.io", url = proto + '//static.' + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->
    
    <div class="page-wraper">
        <header class="site-header header-style-3 topbar-transparent">
            <div class="top-bar">
                <div class="container">
                    <div class="row">
                        <div class="clearfix">
                            <div class="wt-topbar-left">
                                <ul class="list-unstyled e-p-bx pull-left">
                                    <li><i class="fa fa-envelope"></i> <a style="color:white">support@cryptfinanceinvest.com</a>
                                    </li>
                                    <li><i class="fa fa-phone"></i> <a href="#"></a></li>
                                </ul>
                            </div>
                            <div class="wt-topbar-right">
                                <ul class="list-unstyled e-p-bx pull-right">
                                    <li><a href="login.php"><i class="fa fa-user"></i>Login</a></li>
                                    <li><a href="register.php"><i class="fa fa-sign-in"></i>Register</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sticky-header main-bar-wraper">
                <div class="main-bar">
                    <div class="container">
                        <div class="logo-header mostion">
                            <a href="index.php">
                                <img src="/logo.jpeg" width="230" height="67" alt="logo">
                            </a>
                        </div>

                        <button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>

                        <div class="header-nav navbar-collapse collapse ">
                            <ul class=" nav navbar-nav">
                                <li class="active">
                                <a href="index.php">Home</a>
                                </li>
                                <li>
                                <a href="about.html">About Us</a>
                                </li>
                                <li>
                                <a href="terms.html">Terms</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="page-content">
            <div class="main-slider style-two default-banner">
                <div class="tp-banner-container">
                    <div class="tp-banner">
                        <div id="rev_slider_1014_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="typewriter-effect" data-source="gallery">
                            <div id="rev_slider_1014_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
                                <ul>
                                    <li data-index="rs-1000" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="public/images/main-slider/slider2/slide44.jpeg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                                        <img src="public/images/main-slider/slider2/slide44.jpg" alt="" data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina="">


                                        <div class="tp-caption tp-shape tp-shapewrapper " id="slide-100-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" data-width="full" data-height="full" data-whitespace="nowrap" data-type="shape" data-basealign="slide" data-responsive_offset="off" data-responsive="off" data-frames='[
                                                                        {"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},
                                                                        {"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}
                                                                        ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 12;background-color:rgba(0, 0, 0, 0.3);border-color:rgba(0, 0, 0, 0);border-width:0px;">
                                        </div>

                                        <div class="tp-caption   tp-resizeme" id="slide-100-layer-2" data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" data-y="['top','top','top','top']" data-voffset="['308','308','308','308']" data-fontsize="['60','60','60','60']" data-lineheight="['110','110','110','110']" data-width="['6','6','6','6']" data-height="['110,'110','110','110']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                        {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                                                        {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                        ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                        white-space: normal;                                                                    
                                                                        ">
                                            <div class="bg-primary">&nbsp;</div>
                                        </div>

                                        <div class="tp-caption   tp-resizeme" id="slide-100-layer-3" data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" data-y="['top','top','top','top']" data-voffset="['300','300','300','300']" data-fontsize="['55','55','55','45']" data-lineheight="['60','60','60','65']" data-width="['700','700','700','700']" data-height="['none','none','none','none']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                        {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                                                        {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                        ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                        white-space: normal; 
                                                                        font-weight: 700;
                                                                        color: rgb(75, 57, 65);
                                                                        border-width:0px;">
                                            <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase;">
                                            <span class="text-white" style="padding-right:10px;">The
                                            most</span><span class="text-primary">Secure</span>
                                            </div>
                                        </div>

                                        <div class="tp-caption   tp-resizeme" id="slide-100-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" data-y="['top','top','top','top']" data-voffset="['360','360','360','360']" data-fontsize="['53','53','53','45']" data-lineheight="['70','70','70','75']" data-width="['700','700','700','700']" data-height="['none','none','none','none']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                        {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1000,"ease":"Power4.easeOut"},
                                                                        {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                        ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                        white-space: normal; 
                                                                        font-weight: 700;
                                                                        border-width:0px;">
                                            <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase ;">
                                            <span class="text-primary" style="padding-right:10px;">Trading</span><span class="text-white">Platform</span>
                                            </div>
                                        </div>

                                        <div class="tp-caption  tp-resizeme" id="slide-100-layer-5" data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" data-y="['top','top','top','top']" data-voffset="['440','440','440','440']" data-fontsize="['16','16','16','30']" data-lineheight="['30','30','30','40']" data-width="['600','600','600','600']" data-height="['none','none','none','none']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                        {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1500,"ease":"Power4.easeOut"},
                                                                        {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                        ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                        font-weight: 500; 
                                                                        color:#fff;
                                                                        border-width:0px;">
                                            <span style="font-family: 'Poppins', sans-serif;">Profitable Investments
                                            when you trade and invest with us</span>
                                        </div>

                                        <div class="tp-caption tp-resizeme"     
                                            id="slide-100-layer-6"                      
                                            data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 

                                            data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                            data-lineheight="['none','none','none','none']"
                                            data-width="['300','300','300','300']"
                                            data-height="['none','none','none','none']"
                                            data-whitespace="['normal','normal','normal','normal']"

                                            data-type="text" 
                                            data-responsive_offset="on"
                                            data-frames='[ 
                                            {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                            {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                            ]'
                                            data-textAlign="['left','left','left','left']"
                                            data-paddingtop="[0,0,0,0]"
                                            data-paddingright="[0,0,0,0]"
                                            data-paddingbottom="[0,0,0,0]"
                                            data-paddingleft="[0,0,0,0]"

                                            style="z-index:13; text-transform:uppercase;">
                                            <a href="login.php" class="site-button slider-btn-left">LOGIN</a>
                                        </div>

                                        <div class="tp-caption tp-resizeme"     
                                            id="slide-100-layer-7"                      
                                            data-x="['left','left','left','left']" data-hoffset="['220','220','220','320']" 
                                            data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                            data-lineheight="['none','none','none','none']"
                                            data-width="['300','300','300','300']"
                                            data-height="['none','none','none','none']"
                                            data-whitespace="['normal','normal','normal','normal']"

                                            data-type="text" 
                                            data-responsive_offset="on"
                                            data-frames='[ 
                                            {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                            {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                            ]'
                                            data-textAlign="['left','left','left','left']"
                                            data-paddingtop="[0,0,0,0]"
                                            data-paddingright="[0,0,0,0]"
                                            data-paddingbottom="[0,0,0,0]"
                                            data-paddingleft="[0,0,0,0]"

                                            style="z-index:13;
                                            text-transform:uppercase;
                                            font-weight:500;
                                            ">
                                            <a href="register.php" class=" site-button white slider-btn-right">Join Us</a>
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-100-layer-8" data-x="['right','right','right','right']" data-hoffset="['0','0','0','0']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['100','100','100','100']" data-frames='[ 
                                                                        {"from":"y:200px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                                                        {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                        ]' style="z-index: 13;">
                                            <img src="public/images/main-slider/slider2/earth.png" alt="" class="spin-city">
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-100-layer-9" data-x="['right','right','right','right']" data-hoffset="['120','120','120','120']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['180','180','180','180']" data-height="none" data-whitespace="nowrap" data-type="image" data-responsive_offset="on" data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                                                        {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13;">
                                        </div>
                                    </li>

                                    <li data-index="rs-1001" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="public/images/main-slider/slider2/slide44.jpeg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                                        <img src="public/images/main-slider/slider2/slide44.jpg" alt="" data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina="">


                                        <div class="tp-caption tp-shape tp-shapewrapper " id="slide-101-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" data-width="full" data-height="full" data-whitespace="nowrap" data-type="shape" data-basealign="slide" data-responsive_offset="off" data-responsive="off" data-frames='[
                                                                    {"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 12;background-color:rgba(0, 0, 0, 0.3);border-color:rgba(0, 0, 0, 0);border-width:0px;">
                                        </div>

                                        <div class="tp-caption   tp-resizeme" id="slide-101-layer-2" data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" data-y="['top','top','top','top']" data-voffset="['308','308','308','308']" data-fontsize="['60','60','60','60']" data-lineheight="['110','110','110','110']" data-width="['6','6','6','6']" data-height="['110,'110','110','110']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                    white-space: normal;                                                                    
                                                                    ">
                                            <div class="bg-primary">&nbsp;</div>
                                        </div>

                                        <div class="tp-caption   tp-resizeme" id="slide-101-layer-3" data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" data-y="['top','top','top','top']" data-voffset="['300','300','300','300']" data-fontsize="['55','55','55','45']" data-lineheight="['60','60','60','65']" data-width="['700','700','700','700']" data-height="['none','none','none','none']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                    white-space: normal; 
                                                                    font-weight: 700;
                                                                    color: rgb(75, 57, 65);
                                                                    border-width:0px;">
                                            <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase; ">
                                            <span class="text-white" style="padding-right:10px;">Crypto Finance Investment</span><span class="text-primary">TRADING</span>
                                            </div>
                                        </div>

                                        <div class="tp-caption   tp-resizeme" id="slide-101-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" data-y="['top','top','top','top']" data-voffset="['360','360','360','360']" data-fontsize="['53','53','53','45']" data-lineheight="['70','70','70','70']" data-width="['700','700','700','700']" data-height="['none','none','none','none']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1000,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                    white-space: normal; 
                                                                    font-weight: 700;
                                                                    border-width:0px;">
                                            <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase ;">
                                            <span class="text-primary" style="padding-right:10px;">EFFICIENT
                                            </span><span class="text-white">AND RELAIBLE</span>
                                            </div>
                                        </div>

                                        <div class="tp-caption  tp-resizeme" id="slide-101-layer-5" data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" data-y="['top','top','top','top']" data-voffset="['440','440','440','440']" data-fontsize="['16','16','16','30']" data-lineheight="['30','30','30','40']" data-width="['600','600','600','600']" data-height="['none','none','none','none']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1500,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                    font-weight: 500; 
                                                                    color:#fff;
                                                                    border-width:0px;">
                                            <span style="font-family: 'Poppins', sans-serif;">24/7 Live Support. Our
                                            support channels are available anytime everyday</span>
                                        </div>

                                        <div class="tp-caption tp-resizeme"     
                                        id="slide-101-layer-6"                      
                                        data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 
                                        data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                        data-lineheight="['none','none','none','none']"
                                        data-width="['300','300','300','300']"
                                        data-height="['none','none','none','none']"
                                        data-whitespace="['normal','normal','normal','normal']"

                                        data-type="text" 
                                        data-responsive_offset="on"
                                        data-frames='[ 
                                        {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                        {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                        ]'
                                        data-textAlign="['left','left','left','left']"
                                        data-paddingtop="[0,0,0,0]"
                                        data-paddingright="[0,0,0,0]"
                                        data-paddingbottom="[0,0,0,0]"
                                        data-paddingleft="[0,0,0,0]"

                                        style="z-index:13; text-transform:uppercase;">
                                        <a href="login.php" class="site-button slider-btn-left">LOGIN</a>
                                        </div>

                                        <div class="tp-caption tp-resizeme"     
                                        id="slide-101-layer-7"                      
                                        data-x="['left','left','left','left']" data-hoffset="['220','220','220','320']" 
                                        data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                        data-lineheight="['none','none','none','none']"
                                        data-width="['300','300','300','300']"
                                        data-height="['none','none','none','none']"
                                        data-whitespace="['normal','normal','normal','normal']"

                                        data-type="text" 
                                        data-responsive_offset="on"
                                        data-frames='[ 
                                        {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                        {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                        ]'
                                        data-textAlign="['left','left','left','left']"
                                        data-paddingtop="[0,0,0,0]"
                                        data-paddingright="[0,0,0,0]"
                                        data-paddingbottom="[0,0,0,0]"
                                        data-paddingleft="[0,0,0,0]"

                                        style="z-index:13;
                                        text-transform:uppercase;
                                        font-weight:500;
                                        ">
                                        <a href="register.php" class=" site-button white slider-btn-right">Join Us</a>
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-101-layer-8" data-x="['right','right','right','right']" data-hoffset="['-100','-100','-100','-100']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-650','-650','-650','-650']" data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' style="z-index: 13;">
                                            <img src="public/images/main-slider/slider2/earth2.png" alt="" class="spin-city">
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-101-layer-9" data-x="['right','right','right','right']" data-hoffset="['-300','-100','-100','-100']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-200','-200','-200','-200']" data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' style="z-index: 13;">
                                            <img src="public/images/main-slider/slider2/earth2-shadow.png" alt="">
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-101-layer-10" data-x="['right','right','right','right']" data-hoffset="['200','200','200','200']" data-y="['top','bottom','bottom','bottom']" data-voffset="['150','150','150','150']" data-height="none" data-whitespace="nowrap" data-type="image" data-responsive_offset="on" data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 16;">
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-101-layer-11" data-x="['right','right','right','right']" data-hoffset="['278','278','278','278']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['180','100','100','100']" data-height="none" data-whitespace="nowrap" data-type="image" data-responsive_offset="on" data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":4000,"ease":"Power3.easeOut"},
                                                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 15;">
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-101-layer-12" data-x="['right','right','right','right']" data-hoffset="['100','100','100','100']" data-y="['top','bottom','bottom','bottom']" data-voffset="['0','0','0','0']" data-lineheight="['none','none','none','none']" data-width="['500','500','500','500']" data-height="['none','none','none','none']" data-whitespace="nowrap" data-type="image" data-responsive_offset="on" data-frames='[ 
                                                                    {"from":"y:0px(R);opacity:0;","speed":2000,"to":"o:1;","delay":4000,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 12;">
                                            <div class="coin-slide bg-full-width bg-repeat-y coin-slide-rotate" style="background-image:url(public/images/main-slider/slider2/coin-sky.html);height:100vh;">
                                            </div>
                                        </div>
                                    </li>

                                    <li data-index="rs-1002" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="public/images/main-slider/slider2/slide44.jpeg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                                        <img src="public/images/main-slider/slider2/slide44.jpg" alt="" data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina="">


                                        <div class="tp-caption tp-shape tp-shapewrapper " id="slide-102-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" data-width="full" data-height="full" data-whitespace="nowrap" data-type="shape" data-basealign="slide" data-responsive_offset="off" data-responsive="off" data-frames='[
                                                                    {"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 12;background-color:rgba(0, 0, 0, 0.3);border-color:rgba(0, 0, 0, 0);border-width:0px;">
                                        </div>

                                        <div class="tp-caption   tp-resizeme" id="slide-102-layer-2" data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" data-y="['top','top','top','top']" data-voffset="['308','308','308','308']" data-fontsize="['60','60','60','60']" data-lineheight="['110','110','110','110']" data-width="['6','6','6','6']" data-height="['110,'110','110','110']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                    white-space: normal;                                                                    
                                                                    ">
                                            <div class="bg-primary">&nbsp;</div>
                                        </div>

                                        <div class="tp-caption   tp-resizeme" id="slide-102-layer-3" data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" data-y="['top','top','top','top']" data-voffset="['300','300','300','300']" data-fontsize="['55','55','55','45']" data-lineheight="['60','60','60','65']" data-width="['700','700','700','700']" data-height="['none','none','none','none']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                    white-space: normal; 
                                                                    font-weight: 700;
                                                                    color: rgb(75, 57, 65);
                                                                    border-width:0px;">
                                            <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase; ">
                                            <span class="text-primary" style="padding-right:10px;">Crypto Finance Investment</span>
                                            </div>
                                        </div>

                                        <div class="tp-caption   tp-resizeme" id="slide-102-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" data-y="['top','top','top','top']" data-voffset="['360','360','360','360']" data-fontsize="['53','53','53','45']" data-lineheight="['70','70','70','70']" data-width="['700','700','700','700']" data-height="['none','none','none','none']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1000,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                    white-space: normal; 
                                                                    font-weight: 700;
                                                                    border-width:0px;">
                                            <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase ;">
                                            <span class="text-white" style="padding-right:10px;">Easy
                                            Way</span><span class="text-primary">to Trade</span>
                                            </div>
                                        </div>

                                        <div class="tp-caption  tp-resizeme" id="slide-102-layer-5" data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" data-y="['top','top','top','top']" data-voffset="['440','440','440','440']" data-fontsize="['16','16','16','30']" data-lineheight="['30','30','30','40']" data-width="['600','600','600','600']" data-height="['none','none','none','none']" data-whitespace="['normal','normal','normal','normal']" data-type="text" data-responsive_offset="on" data-frames='[
                                                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1500,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13; 
                                                                    font-weight: 500; 
                                                                    color:#fff;
                                                                    border-width:0px;">
                                            <span style="font-family: 'Poppins', sans-serif;">Trade in the most popular
                                            currencies of your choice; USD, GBD, AUD, BTC, CNY, EUR, CAD </span>
                                        </div>

                                        <div class="tp-caption tp-resizeme"     
                                        id="slide-102-layer-6"                      
                                        data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 
                                        data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                        data-lineheight="['none','none','none','none']"
                                        data-width="['300','300','300','300']"
                                        data-height="['none','none','none','none']"
                                        data-whitespace="['normal','normal','normal','normal']"

                                        data-type="text" 
                                        data-responsive_offset="on"
                                        data-frames='[ 
                                        {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                        {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                        ]'
                                        data-textAlign="['left','left','left','left']"
                                        data-paddingtop="[0,0,0,0]"
                                        data-paddingright="[0,0,0,0]"
                                        data-paddingbottom="[0,0,0,0]"
                                        data-paddingleft="[0,0,0,0]"

                                        style="z-index:13; text-transform:uppercase;">
                                        <a href="login.php" class="site-button slider-btn-left">LOGIN</a>
                                        </div>

                                        <div class="tp-caption tp-resizeme"     
                                        id="slide-102-layer-7"                      
                                        data-x="['left','left','left','left']" data-hoffset="['220','220','220','320']" 
                                        data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                        data-lineheight="['none','none','none','none']"
                                        data-width="['300','300','300','300']"
                                        data-height="['none','none','none','none']"
                                        data-whitespace="['normal','normal','normal','normal']"

                                        data-type="text" 
                                        data-responsive_offset="on"
                                        data-frames='[ 
                                        {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                        {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                        ]'
                                        data-textAlign="['left','left','left','left']"
                                        data-paddingtop="[0,0,0,0]"
                                        data-paddingright="[0,0,0,0]"
                                        data-paddingbottom="[0,0,0,0]"
                                        data-paddingleft="[0,0,0,0]"

                                        style="z-index:13;
                                        text-transform:uppercase;
                                        font-weight:500;
                                        ">
                                        <a href="register.php" class=" site-button white slider-btn-right">Join Us</a>
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-102-layer-8" data-x="['right','right','right','right']" data-hoffset="['0','0','0','0']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-20','-20','-20','-20']" data-frames='[ 
                                                                    {"from":"y:200px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' style="z-index: 13;">
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-102-layer-9" data-x="['right','right','right','right']" data-hoffset="['320','320','320','320']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['130','130','130','130']" data-frames='[ 
                                                                    {"from":"y:-500px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                                                    ]' style="z-index: 13;">
                                        </div>

                                        <div class="tp-caption tp-resizeme" id="slide-102-layer-10" data-x="['right','right','right','right']" data-hoffset="['20','20','20','20']" data-y="['bottom','bottom','bottom','bottom']" data-voffset="['80','80','80','80']" data-height="none" data-whitespace="nowrap" data-type="image" data-responsive_offset="on" data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]' data-textalign="['left','left','left','left']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 13;">
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-black marquee">
                <div class="TickerNews" id="T1">
                    <div class="ti_wrapper">
                        <div class="ti_slide">
                            <div class="ti_content">
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/bitcoin.png" alt=""><span>BTC:
                                </span><span>$ 10,633.1</span><span class="text-yellow p-lr5">0.97 %</span></a>
                                </div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/bitcoin.png" alt=""><span>BTC:
                                </span><span>¥ 68,008.1</span><span class="text-danger p-lr5">0.00 %</span></a>
                                </div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/bitcoin.png" alt=""><span>BTC:
                                </span><span>€ 8,699.23</span><span class="text-white p-lr5">1.08 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/Ethereum.png" alt=""><span>ETH:
                                </span><span>Ƀ 0.08160</span><span class="text-green p-lr5">-0.28 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/Ethereum.png" alt=""><span>ETH:
                                </span><span>$ 867.93</span><span class="text-danger p-lr5">-0.60 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/Ethereum.png" alt=""><span>ETH:
                                </span><span>¥ 5,549.46</span><span class="text-white p-lr5">-0.28 %</span></a>
                                </div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/Ethereum.png" alt=""><span>ETH:
                                </span><span>€ 709.94</span><span class="text-gray p-lr5">0.26 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/monero.png" alt=""><span>XMR:
                                </span><span>Ƀ 0.0276</span><span class="text-green p-lr5">1.25 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/monero.png" alt=""><span>XMR:
                                </span><span>$ 295.33</span><span class="text-light-blue p-lr5">0.89 %</span></a>
                                </div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/monero.png" alt=""><span>XMR:
                                </span><span>¥ 1,883.14</span><span class="text-green p-lr5">0.25 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/monero.png" alt=""><span>XMR:
                                </span><span>€ 240.56</span><span class="text-red p-lr5">-0.40 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/litecoin.png" alt=""><span>LTC:
                                </span><span>Ƀ 0.01956</span><span class="text-danger p-lr5">-0.20 %</span></a>
                                </div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/litecoin.png" alt=""><span>LTC:
                                </span><span>$ 208.06</span><span class="text-green p-lr5">-1.97 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/litecoin.png" alt=""><span>LTC:
                                </span><span>¥ 1,330.24</span><span class="text-white p-lr5">-0.20 %</span></a>
                                </div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/litecoin.png" alt=""><span>LTC:
                                </span><span>€ 169.91</span><span class="text-yellow p-lr5">-1.29 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/DigitalCash.png" alt=""><span>DASH:
                                </span><span>Ƀ 0.05590</span><span class="text-white p-lr5">0.26 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/DigitalCash.png" alt=""><span>DASH:
                                </span><span>$ 594.64</span><span class="text-green p-lr5">0.37 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/DigitalCash.png" alt=""><span>DASH:
                                </span><span>¥ 3,801.65</span><span class="text-red p-lr5">0.99 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="public/images/coin-icon/DigitalCash.png" alt=""><span>DASH:
                                </span><span>€ 486.29</span><span class="text-yellow p-lr5">-10.18 %</span></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-full bg-primary">
                <div class="container">
                    <div class="section-content ">

                        <div class="wt-subscribe-box">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-9 col-sm-9">
                                        <div class="call-to-action-left p-tb20 ">
                                            <h4 class="text-uppercase m-b10 font-weight-600">
                                            WHY TRADE WITH Crypto Finance Investment                                            </h4>
                                            <p>Since its establishment, Crypto Finance Investment LIVE TRADING has shown
                                            commendably successful and consistent performance and trading history.
                                            Currently, it is regarded as one of the best, most beneficial,
                                            brilliantly successful companies in the industry of forex trading and
                                            investing</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="call-to-action-right p-tb30">
                                            <a href="about.html" class="site-button-secondry text-uppercase font-weight-600">
                                            Read More
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-full home-about-section p-t80 bg-no-repeat bg-bottom-right" style="background-image:url(public/images/background/bg-coin.png)">
                <div class="container-fluid ">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="wt-box text-right">
                                <img src="public/images/background/tr.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="wt-right-part p-b80">

                                <div class="section-head text-left">
                                    <span class="wt-title-subline font-16 text-gray-dark m-b15">we are secured With
                                    latest server security tech,highest encryption level, we stay protected
                                    24/7</span>
                                    <h2 class="text-uppercase">Ultimate Pairs</h2>
                                    <div class="wt-separator-outer">
                                        <div class="wt-separator bg-primary"></div>
                                    </div>
                                </div>

                                <div class="section-content">
                                    <div class="wt-box">
                                        <p>
                                        <strong>Best asset management and financial concept that you will see in the
                                        current industry. We make it our mission to meet our clients’ needs and
                                        security right away.
                                        </strong>
                                        </p>
                                        <p>Our forex transactions are fast safe and secured. Payments should only be
                                        made on the website..</p>
                                        <a href="about.html" class="site-button text-uppercase m-r15">Read More</a>
                                        <a href="about.html" class="site-button-secondry text-uppercase">Contact
                                        us</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-full  p-t80 p-b80 bg-gray">
                <div class="container">

                    <div class="section-head text-center">
                        <span class="wt-title-subline font-16 text-gray-dark m-b15"></span>
                        <h2 class="text-uppercase">our investment plans</h2>
                        <div class="wt-separator-outer">
                            <div class="wt-separator bg-primary"></div>
                        </div>
                        <p></p>
                    </div>

                    <div class="section-content no-col-gap">
                        <div class="row">

                            <div class="col-md-3 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                        <a href="#" class="icon-cell"><img src="public/images/icon/pick-12345.png" alt=""></a>
                                    </div>
                                    <div class="icon-content">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">BASIC PLAN</h4>
                                        <p>Minimum Deposit - $500.00</p>
                                        <!--<br>Profit - $4,500.00 and above-->
                                    </div>
                                </div>
                            </div>    

                            <div class="col-md-3 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                        <a href="#" class="icon-cell"><img src="public/images/icon/pick-29.png" alt=""></a>
                                    </div>
                                    <div class="icon-content">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">BRONZE PLAN</h4>
                                        <p>Minimum Deposit - $1,500.00</p>
                                        <!--<br>Profit - $9,500.00 and above-->
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                        <a href="#" class="icon-cell"><img src="public/images/icon/pick-28.png" alt=""></a>
                                    </div>
                                    <div class="icon-content ">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">SILVER PLAN</h4>
                                        <p>Minimum Deposit - $5,000.00</p>
                                        <!--<br>Profit - $19,540.00 and Above-->
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                        <a href="#" class="icon-cell"><img src="public/images/icon/pick-19.png" alt=""></a>
                                    </div>
                                    <div class="icon-content">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">GOLD PLAN</h4>
                                        <p>Minimum Deposit - $10,000.00</p>
                                        <!--<br>Profit- $32,450.00 and Above-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-full home-about-section p-tb80 bg-no-repeat bg-bottom-right bg-gray" style="background-image:url(public/images/background/bg-coin.png)">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="btcwdgt-chart" bw-theme="light">
                                <script>
                                 (function(b,i,t,C,O,I,N) {
                                      window.addEventListener('load',function() {
                                      if(b.getElementById(C))return;
                                      I=b.createElement(i),N=b.getElementsByTagName(i)[0];
                                      I.src=t;I.id=C;N.parentNode.insertBefore(I, N);
                                    },false)
                                  })(document,'script','../widgets.bitcoin.com/widget.js','btcwdgt');
                                </script>
                            </div>
                         </div>
                        <div class="col-md-6">
                            <div class="p-b20 text-left">
                                <span class="wt-title-subline font-16 text-gray-dark m-b15"></span>
                                <h2 class="text-uppercase">How Bitcoin Works</h2>
                                <div class="wt-separator-outer">
                                    <div class="wt-separator bg-primary"></div>
                                </div>
                            </div>

                            <div class="section-content">
                                <div class="wt-box">
                                    <p>
                                    <strong>Once you've installed a Bitcoin wallet on your computer or mobile phone,
                                    it will generate your first Bitcoin address and you can create more whenever
                                    you need one.
                                    </strong>
                                    </p>
                                    <p>You can disclose your addresses to your friends so that they can pay you or vice
                                    versa. In fact, this is pretty similar to how email works, except that Bitcoin
                                    addresses should be used only once.</p>
                                    <a href="login.php" class="site-button text-uppercase m-r15">Login</a>
                                    <a href="register.php" class="site-button-secondry text-uppercase">Get
                                    Started</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-full p-t50 p-b50 overlay-wraper bg-parallax clouds1 bg-repeat" data-stellar-background-ratio="0.5" style="background-image:url(public/images/background/bg-9.jpg);">
                <div class="overlay-main bg-secondry opacity-05"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-sm-6">
                            <!-- TradingView Widget BEGIN -->
                            <div class="tradingview-widget-container">
                              <div id="tradingview_f933e"></div>
                              <div class="tradingview-widget-copyright"><a href="#" rel="noopener" target="_blank"><span class="blue-text"></span> <span class="blue-text">Crypto Finance Investment Chart</span></a></div>
                              <script type="text/javascript" src="../s3.tradingview.com/tv.js"></script>
                              <script type="text/javascript">
                              new TradingView.widget(
                              {
                              "width": 300,
                              "height": 300,
                              "symbol": "BITFINEX:BTCUSD",
                              "interval": "1",
                              "timezone": "Etc/UTC",
                              "theme": "Dark",
                              "style": "9",
                              "locale": "en",
                              "toolbar_bg": "#f1f3f6",
                              "enable_publishing": false,
                              "hide_side_toolbar": false,
                              "allow_symbol_change": true,
                              "calendar": true,
                              "studies": [
                                "BB@tv-basicstudies"
                              ],
                              "container_id": "tradingview_f933e"
                            }
                              );
                              </script>
                            </div>
                            <!-- TradingView Widget END -->           
                        </div>
                        <div class="col-md-8 col-sm-6">
                            <div class="awesome-counter text-right text-white">
                                <h3 class="font-24">Crypto Finance Investment</h3>
                                <h2 class="font-60 font-weight-600"><span class="text-primary"> MORE ABOUT US</span>
                                </h2>
                                <p>With our all New strategy on bitcoin and forex trades, we make up to 98% daily wins,
                                we also have a bitcoin mining team working with our platform. We generate a profit
                                of 3BTC daily which equals $47,686 in today's market. Our company is SEC registered,
                                fully licensed and Insured, your initial capital invest is 100% insured</p>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="status-marks  text-white m-tb10">
                                        <div class="status-value text-right">
                                            <span class="counter">8150</span>
                                            <i class="fa fa-building font-26 m-l15"></i>
                                        </div>
                                        <h6 class="text-uppercase text-right">PROJECT COMPLETED</h6>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="status-marks  text-white m-tb10">
                                        <div class="status-value text-right">
                                            <span class="counter">5223</span>
                                            <i class="fa fa-users font-26 m-l15"></i>
                                        </div>
                                        <h6 class="text-uppercase text-white text-right">HAPPY CLIENTS</h6>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="status-marks  text-white m-tb10">
                                        <div class="status-value text-right">
                                            <span class="counter">4522</span>
                                            <i class="fa fa-user-plus font-26 m-l15"></i>
                                        </div>
                                        <h6 class="text-uppercase text-white text-right">WORKERS EMPLOYED</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-full  p-t80 p-b80 bg-gray">
                <div class="container">

                    <div class="section-head text-center">
                        <span class="wt-title-subline font-16 text-gray-dark m-b15"></span>
                        <h2 class="text-uppercase">Latest Withdrawals</h2>
                        <div class="wt-separator-outer">
                            <div class="wt-separator bg-primary"></div>
                        </div>
                        <p></p>
                    </div>

                    <div class="table-responsive" style="height:400px; overflow-y:auto; overflow-x:auto;">
                        <marquee direction="down" height="100%">
                            <table class="table" style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Status</th>
                                        <th class="text-center">Amount(USD)</th>
                                        <th class="text-center">Wallet</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$10,000.00</td>
                                        <td class="text-center">
                                        3a17c5984af22cd7a443f14457841b3b19a51ea75a30e18bc6a82e4f8732dbca
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$51,000.00</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$24,100.00</td>
                                        <td class="text-center">
                                        f007e92cc9f82ba9c8c40c481eec7315fa9abcd85e7249a6cb57e38a2cf22d3e
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$4,000.00</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$500</td>
                                        <td class="text-center">
                                        00db85ef40da34f3ea76aa60f0b2053eec2d90121e450791c18d8edbfedde6f1
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$240,000</td>
                                        <td class="text-center">
                                        b21a418a44ed8b56118facefe7aa8d26541dff811b8a8ca65cfa1346d62c5c48
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$17,000</td>
                                        <td class="text-center">
                                        1e652d2899a1d058a20041a9faaeb5dc009101ca412ff09c387e6b281bd1db8b
                                        </td>
                                    </tr>
                                    <tr>
                                         <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$51,000</td>
                                        <td class="text-center">
                                        6a49e66a66f75e72e6bd383ac798792af204a6693708912ad0d48e363a2ab7a7
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$21,000</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$6,000</td>
                                        <td class="text-center">
                                        797ba039291417fdbdb411ea0a102d23090cde9ac7799ff605f40b5db484891d
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$9,000</td>
                                        <td class="text-center">
                                        f0b66ce7a33bbc63bf50050beaf52be71709c359aa1d344bb90f943690485661
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$23,000</td>
                                        <td class="text-center">
                                        2083e95ada3c584471ba5982e16c5dc2a6e464d3c170555ea8c708668be9383b
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$51,000</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$5,000</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">5,000</td>
                                        <td class="text-center">
                                        15c3a97edbd606bd1e455aa2875677f5c6cd2b804e9054e898f640d313e39781
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$18,000</td>
                                        <td class="text-center">
                                        66c13496e9d53a2402fd49bbe91df298164472679cc868bbfebbabb4844d784c
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$2,500</td>
                                        <td class="text-center">
                                        ce972a6b82135fcba0890ea0c8668bdddf782fd580672daa6616c3b1af40ca9f
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$9,000</td>
                                        <td class="text-center">
                                        376e809b02e6ef044f6d5cf5b72111f25f3c3e16a93dce865a178e2e0f5c484c
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$43,000</td>
                                        <td class="text-center">
                                        aa14458f8082d9c4265ef491ca0b5d4801c16bbf7a4aece7b70a0b4824ffdfea
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$10,000.00</td>
                                        <td class="text-center">
                                        3a17c5984af22cd7a443f14457841b3b19a51ea75a30e18bc6a82e4f8732dbca
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$51,000.00</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$24,100.00</td>
                                        <td class="text-center">
                                        f007e92cc9f82ba9c8c40c481eec7315fa9abcd85e7249a6cb57e38a2cf22d3e
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$4,000.00</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$500</td>
                                        <td class="text-center">
                                        00db85ef40da34f3ea76aa60f0b2053eec2d90121e450791c18d8edbfedde6f1
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$240,000</td>
                                        <td class="text-center">
                                        b21a418a44ed8b56118facefe7aa8d26541dff811b8a8ca65cfa1346d62c5c48
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$17,000</td>
                                        <td class="text-center">
                                        1e652d2899a1d058a20041a9faaeb5dc009101ca412ff09c387e6b281bd1db8b
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$51,000</td>
                                        <td class="text-center">
                                        6a49e66a66f75e72e6bd383ac798792af204a6693708912ad0d48e363a2ab7a7
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$21,000</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$6,000</td>
                                        <td class="text-center">
                                        797ba039291417fdbdb411ea0a102d23090cde9ac7799ff605f40b5db484891d
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$9,000</td>
                                        <td class="text-center">
                                        f0b66ce7a33bbc63bf50050beaf52be71709c359aa1d344bb90f943690485661
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$23,000</td>
                                        <td class="text-center">
                                        2083e95ada3c584471ba5982e16c5dc2a6e464d3c170555ea8c708668be9383b
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$51,000</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$5,000</td>
                                        <td class="text-center">
                                        8a2b9781aa4995625af7d2b008f020ac74e7e0d2a599e93ed995f7c3bc2be9f2
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">5,000</td>
                                        <td class="text-center">
                                        15c3a97edbd606bd1e455aa2875677f5c6cd2b804e9054e898f640d313e39781
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$18,000</td>
                                        <td class="text-center">
                                        66c13496e9d53a2402fd49bbe91df298164472679cc868bbfebbabb4844d784c
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$2,500</td>
                                        <td class="text-center">
                                        ce972a6b82135fcba0890ea0c8668bdddf782fd580672daa6616c3b1af40ca9f
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn
                                                                                    btn-info btn-sm"><span class="btn-label"><i class="fa
                                                                                    fa-check"></i></span>Confirmed</button></td>
                                        <td class="text-center">$9,000</td>
                                        <td class="text-center">
                                        376e809b02e6ef044f6d5cf5b72111f25f3c3e16a93dce865a178e2e0f5c484c
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><button class="btn btn-warning btn-sm"><span class="btn-label"><i class="fa fa-warning"></i></span>Pending</button></td>
                                        <td class="text-center">$43,000</td>
                                        <td class="text-center">
                                        aa14458f8082d9c4265ef491ca0b5d4801c16bbf7a4aece7b70a0b4824ffdfea
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </marquee>
                    </div>
                </div>
            </div>

            <div class="section-full  p-t80 p-b80 bg-gray">
                <div class="container">

                    <div class="section-head text-center">
                        <span class="wt-title-subline font-16 text-gray-dark m-b15"></span>
                        <h2 class="text-uppercase">Why Choose Us</h2>
                        <div class="wt-separator-outer">
                            <div class="wt-separator bg-primary"></div>
                        </div>
                        <p></p>
                    </div>

                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <div class="service_single_content text-center mb-100 fadeInUp" data-wow-delay="0.2s">
                                <div class="service_icon">
                                    <img src="public/img/icons/1.png" alt="">
                                </div>
                                <h6>Recurring Buying</h6>
                                <p>We engage in recurrent buying. Once we notice a pattern on a certain asset, we lock in trades
                                to make recurrent buying.</p>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="service_single_content text-center mb-100 fadeInUp" data-wow-delay="0.3s">
                                <div class="service_icon">
                                    <img src="public/img/icons/2.png" alt="">
                                </div>
                                <h6>Instant Trading</h6>
                                <p>All our dealings are transparent as our clients can see all their live trades which we make
                                on their behalf in real time.</p>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="service_single_content text-center mb-100 fadeInUp" data-wow-delay="0.4s">
                                <div class="service_icon">
                                    <img src="public/img/icons/3.png" alt="">
                                </div>
                                <h6>Investment Planning</h6>
                                <p>Our wealth of experience has seen us make very good trading decisions over the years.</p>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="service_single_content text-center mb-100 fadeInUp" data-wow-delay="0.5s">
                                <div class="service_icon">
                                    <img src="public/img/icons/4.png" alt="">
                                </div>
                                <h6>Covered By Insurance</h6>
                                <p>We are well insured against loss. This means that all our client's funds are safe and we are
                                covered by insurance.</p>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="service_single_content text-center mb-100 fadeInUp" data-wow-delay="0.6s">
                                <div class="service_icon">
                                    <img src="public/img/icons/5.png" alt="">
                                </div>
                                <h6>Safe and Secure</h6>
                                <p>All our trade decisions are precise and secure. We put the security of our clients funds
                                before anything else.</p>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">

                            <div class="service_single_content text-center mb-100 fadeInUp" data-wow-delay="0.7s">
                                <div class="service_icon">
                                    <img src="public/img/icons/6.png" alt="">
                                </div>
                                <h6>Bitcoin Transaction</h6>
                                <p>We perform our transactions with bitcoin. This is because the blockchain is a safe, secure
                                and de-centralised system.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-full  p-tb80 bg-full-height bg-repeat-x graph-slide-image" style="background-image:url(public/images/background/bg-1.jpg);">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6  clearfix">
                            <div class="bit-converter p-a40 p-b15 bg-white">
                                <div class="wt-box">
                                    <h2 class="text-uppercase m-t0 text-primary">What Is Bitcoin</h2>
                                </div>
                                <div class="currency-calculator sp-one">
                                    <div class="btc-clc">
                                        <iframe width="420" height="315" src="https://www.youtube.com/embed/Gc2en3nHxA4"></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="wt-box graph-part-right text-white">
                                <strong class="text-uppercase title-first">About Forex</strong>
                                <span class="text-uppercase text-primary display-block title-second"></span>
                                 <p><strong>What is Forex?
                                Forex, also known as foreign exchange, FX or currency trading, is a
                                decentralized global market where all the world's currencies trade. The forex
                                market is the largest, most liquid market in the world with an average daily
                                trading volume exceeding $5 trillion.</strong>
                                </p>
                                <ul class="list-check-circle primary">
                                    <li>All forex trades involve two currencies because you're betting on the value of a
                                    currency against another. Think of EUR/USD, the most-traded currency pair in the
                                    world. EUR, the first currency in the pair, is the base, and USD, the second, is
                                    the counter. When you see a price quoted on your platform, that price is how
                                    much one euro is worth in US dollars. You always see two prices because one is
                                    the buy price and one is the sell. The difference between the two is the spread.
                                    When you click buy or sell, you are buying or selling the first currency in the
                                    pair.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-full no-col-gap bg-repeat">
                <div class="container-fluid">
                        
                    <div class="row">
                        <div class="col-md-6 col-sm-6 bg-secondry">
                            <div class="section-content p-tb60 p-r30 clearfix">
                                <div class="wt-left-part any-query">
                                    <img src="images/any-query.html" alt="">
                                    <div class="text-center">
                                        <h3 class="text-uppercase font-weight-500 text-white">Any Question?</h3>
                                        <p class="text-white">
                                            Contact our whatsapp customer support
                                        </p>
                                        <h4 class="text-primary">+</h4>
                                    </div>    
                                </div>
                            </div>                               
                        </div>
                        <div class="col-md-6 col-sm-6 bg-primary">
                            <div class="section-content p-tb60 p-l30 clearfix">
                                <div class="wt-right-part any-query-contact">
                                    <img src="images/any-query-contact.html" alt="">
                                    <div class="text-center">
                                        <h3 class="text-uppercase font-weight-500 text-white">Email Support</h3>
                                        <p class="text-white">Send an email to our support team via</p>
                                        <h5 class="text-secondry">support@cryptfinanceinvest.com</h5>
                                    </div>                               
                                </div>                                
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
 

            <div class="section-full p-t80 p-b50 bg-center bg-full-height bg-no-repeat" style="background-image:url(public/images/background/bg-testimonial.jpg);">
                <div class="container">

                    <div class="section-head text-center">
                        <span class="wt-title-subline font-16 text-gray-dark m-b15"></span>
                        <h2 class="text-uppercase">HEAR FROM OUR CLIENTS</h2>
                        <div class="wt-separator-outer">
                            <div class="wt-separator bg-primary"></div>
                        </div>
                    </div>

                    <div class="section-content">
                        <div class="owl-carousel home-carousel-1">
                            <div class="item">
                                <div class="testimonial-5">
                                    <div class="testimonial-pic-block radius-bx">
                                        <div class="testimonial-pic radius">
                                            <img src="img/testimonials/pic40.jpg" width="132" height="132" alt="">
                                        </div>
                                    </div>
                                    <div class="testimonial-text clearfix">
                                        <div class="testimonial-paragraph">
                                            <span class="fa fa-quote-left text-primary"></span>
                                            <p>Easy, Fast And reliable. got my profits immediately after trading. Crypto Finance Investment is Awesome
                                            </p>
                                        </div>
                                        <div class="testimonial-detail clearfix">
                                            <strong class="testimonial-name">JAMES KIRK</strong><br>Model
                                            <span class="testimonial-position text-primary p-t10">SOUTH AFRICA</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-5">
                                    <div class="testimonial-pic-block radius-bx">
                                        <div class="testimonial-pic radius">
                                            <img src="img/testimonials/pic30.jpg" width="132" height="132" alt="">
                                        </div>
                                    </div>
                                    <div class="testimonial-text clearfix">
                                        <div class="testimonial-paragraph">
                                            <span class="fa fa-quote-left text-primary"></span>
                                            <p>The program like cryptfinanceinvest.com enables me to execute the kind of one-on-one business Ive looking for. Its the kind of product that is taking our business to a different level.
                                            </p>
                                        </div>
                                        <div class="testimonial-detail clearfix">
                                            <strong class="testimonial-name">RINDA SMITH</strong><br>Real Estate Agent
                                            <span class="testimonial-position text-primary p-t10">UK</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-5">
                                    <div class="testimonial-pic-block radius-bx">
                                        <div class="testimonial-pic radius">
                                            <img src="img/testimonials/pic20.jpg" width="132" height="132" alt="">
                                        </div>
                                    </div>
                                    <div class="testimonial-text clearfix">
                                        <div class="testimonial-paragraph">
                                            <span class="fa fa-quote-left text-primary"></span>
                                            <p>Ive always liked good stylish programs, but never invested quite enough to have a good profit. Now, thanks to cryptfinanceinvest.com, we have a program we can be proud of.
                                            </p>
                                        </div>
                                        <div class="testimonial-detail clearfix">
                                            <strong class="testimonial-name">PAUL WILLS</strong><br>Pro Trader
                                            <span class="testimonial-position text-primary p-t10">USA</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-5">
                                    <div class="testimonial-pic-block radius-bx">
                                        <div class="testimonial-pic radius">
                                            <img src="img/testimonials/pic50.jpg" width="132" height="132" alt="">
                                        </div>
                                    </div>
                                    <div class="testimonial-text clearfix">
                                        <div class="testimonial-paragraph">
                                            <span class="fa fa-quote-left text-primary"></span>
                                            <p>Your company is exactly what I was looking for – clear, clean, continuous, with a focus on clients. Thank you so much for your work.
                                            </p>
                                        </div>
                                        <div class="testimonial-detail clearfix">
                                            <strong class="testimonial-name">ROSE POWELL</strong><br>Bitcoin Analyst
                                            <span class="testimonial-position text-primary p-t10">CANADA</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <footer class="site-footer bg-no-repeat bg-full-height bg-center" style="background-image:url(public/images/background/footer-bg.jpg);">

                <div class="footer-top overlay-wraper">
                    <div class="overlay-main bg-black opacity-05"></div>
                    <div class="container">
                        <div class="row">

                            <div class="col-md-4 col-sm-6">
                                <div class="widget widget_about">
                                    <div class="logo-footer clearfix p-b15">
                                        <a href="index.php"><img src="/logo.jpeg" width="230" height="67" alt=""></a>
                                    </div>
                                    <p>Since its establishment, we have shown commendably successful and consistent
                                    performance
                                    and trading history. Currently, it is regarded as one of the best, most beneficial,
                                    brilliantly successful companies in the industry of forex trading and investing.
                                    </p>
                                </div>
                            </div>

                            <div class="col-md-4 col-sm-6">
                                <div class="widget widget_services">
                                    <h4 class="widget-title text-white">Useful links</h4>
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about.html">About Us</a></li>
                                        <li><a href="terms.html">Terms</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-4 col-sm-6  p-tb20">

                                <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix">

                                    <div class="icon-md text-primary">

                                        <span class="iconmoon-travel"></span>

                                    </div>

                                    <div class="icon-content text-white">

                                        <h5 class="wt-tilte text-uppercase m-b0">Address</h5>

                                        <p class="m-b0">3423 Piedmont Rd, NE #516, Atlanta USA</p>

                                    </div>

                                </div>

                            </div>

                            <div class="col-md-4 col-sm-6  p-tb20 ">

                                <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix">

                                    <div class="icon-md text-primary">

                                        <span class="iconmoon-smartphone-1"></span>

                                    </div>

                                    <div class="icon-content text-white">

                                        <h5 class="wt-tilte text-uppercase m-b0">Phone</h5>

                                        <p class="m-b0"></p>

                                    </div>

                                </div>

                            </div>

                            <div class="col-md-4 col-sm-6 p-tb20">

                                <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix">

                                    <div class="icon-md text-primary">

                                        <span class="iconmoon-email"></span>

                                    </div>

                                    <div class="icon-content text-white">

                                        <h5 class="wt-tilte text-uppercase m-b0">Email</h5>

                                        <p class="m-b0">support@cryptfinanceinvest.com</p>

                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>

                <div class="footer-bottom  overlay-wraper">
                    <div class="overlay-main"></div>
                    <div class="constrot-strip"></div>
                    <div class="container p-t30">
                        <div class="row">
                            <div class="wt-footer-bot-left">
                                <span class="copyrights-text">&copy; 2013 - 2023 Crypto Finance Investment. All Rights Reserved.</span>
                            </div>
                        </div>
                    </div>
                </div>

            </footer>

            <button class="scroltop"><span class=" iconmoon-house relative" id="btn-vibrate"></span>Top</button>

        </div>

        <!-- LOADING AREA START ===== -->
        <div class="loading-area">
            <div class="loading-box"></div>
            <div class="loading-pic">
                <div class="cssload-container">
                    <div class="cssload-dot bg-primary"><i class="fa fa-bitcoin"></i></div>
                    <div class="step" id="cssload-s1"></div>
                    <div class="step" id="cssload-s2"></div>
                    <div class="step" id="cssload-s3"></div>
                </div>
            </div>
        </div>
        <!-- LOADING AREA  END ====== -->

        <script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare/email-decode.min.23.html"></script>
        <script src="public/js/jquery-1.12.4.min.js"></script>
        <script src="public/js/bootstrap.min.js"></script>
        <script src="public/js/bootstrap-select.min.js"></script>
        <script src="public/js/jquery.bootstrap-touchspin.min.js"></script>
        <script src="public/js/magnific-popup.min.js"></script>
        <script src="public/js/waypoints.min.js"></script>
        <script src="public/js/counterup.min.js"></script>
        <script src="public/js/waypoints-sticky.min.js"></script>
        <script src="public/js/isotope.pkgd.min.js"></script>
        <script src="public/js/owl.carousel.min.js"></script>
        <script src="public/js/stellar.min.js"></script>
        <script src="public/js/scrolla.min.js"></script>
        <script src="public/js/custom.js"></script>
        <script src="public/js/shortcode.js"></script>
        <script src="public/js/jquery.bgscroll.js"></script>
        <script src="public/js/tickerNews.min.js"></script>
        <script type="text/javascript">
            jQuery(function(){
            var timer = !1;
            _Ticker = jQuery("#T1").newsTicker();
            _Ticker.on("mouseenter",function(){
                var __self = this;
                timer = setTimeout(function(){
                    __self.pauseTicker();
                },200);
            });
            _Ticker.on("mouseleave",function(){
                clearTimeout(timer);
                if(!timer) return !1;
                this.startTicker();
            });
        });
        </script>

        <script src="public/plugins/revolution/revolutio/jquery.themepunch.txt"></script>
        <script src="public/plugins/revolution/revolutio/jquery.themepunch-1.txt"></script>

        <script src="public/plugins/revolution/revolutio/revolution-plugin.4a.txt"></script>

        <script src="public/js/rev-script-1.js"></script>

        <div class="mgm" style="display: none;">
            <div class="txt" style="color:black;"></div>
        </div>
        <script src="notify.js"></script>
        <link rel="stylesheet" href="toastr.min.css">
        <script src="toastr.min.js"></script>
        <script src="../cdnjs.cloudflare.com/ajax/libs/Faker/3.1.0/faker.min.js"></script>
        <script data-cfasync="false" src="#"></script>
        <script type="text/javascript">
        setInterval(function(){
            var listCountries = ['South Africa', 'USA', 'Germany', 'France', 'Italy', 'South Africa', 'Australia', 'South Africa', 'Canada', 'Argentina', 'Saudi Arabia', 'Mexico', 'South Africa', 'South Africa', 'Venezuela', 'South Africa', 'Sweden', 'South Africa', 'South Africa', 'Italy', 'South Africa', 'United Kingdom', 'South Africa', 'Greece', 'Cuba', 'South Africa', 'Portugal', 'Austria', 'South Africa', 'Panama', 'South Africa', 'South Africa', 'Netherlands', 'Switzerland', 'Belgium', 'Israel', 'Cyprus'];
            
            var cash = '$' + (Math.random()*100000).toFixed(2);

            var listPlans = [cash];
            var transarray = ['just <b>invested</b>', 'has <b>withdrawn</b>', 'is <b>trading with</b>'];
            interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000);
            var run = setInterval(request, interval);
        
            function request() {
                clearInterval(run);
                interval = Math.floor(Math.random() * (40000 - 8000 + 1) + 8000);
                var country = listCountries[Math.floor(Math.random() * listCountries.length)];
                var transtype = transarray[Math.floor(Math.random() * transarray.length)];
                var plan = listPlans[Math.floor(Math.random() * listPlans.length)];
                var msg = 'Someone from <b>' + country + '</b> ' + transtype + ' <a href="javascript:void(0);" onclick="javascript:void(0);">' + plan + '</a>';
                $(".mgm .txt").html(msg);
                $(".mgm").stop(true).fadeIn(300);
                window.setTimeout(function() {
                    $(".mgm").stop(true).fadeOut(300);
                }, 10000);
                run = setInterval(request, interval);
            }
            
             }, 10000);

            setInterval(function(){
            let info = faker.helpers.createCard();
            let {name, email, address:{city,country,zipcode}} = info; 
            var amount = (Math.random()*10000).toFixed(2);
            var label_message = name+" invested the sum of $"+amount;
        </script>
        <script src="//code.tidio.co/q4tbmzmfp7h7mkb3rztywtvtiyrquv59.js" async></script>   </body>

<!-- Mirrored from www.cryptfinanceinvest.com/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 Dec 2023 13:55:29 GMT -->
</html>