<?php
require_once('header.php');
if ($user_data['role'] !== '1') {
    die('Not alllowed.');
}

function get_userdata($id, $value)
{
    global $mysqli;
    $sql = "SELECT * FROM users WHERE id='$id'";
    $result = $mysqli->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row["$value"];
    } else {
        return 'Unknown';
    }
}

$errors = [];
$success = [];
$email = $password = "";
$show_success = $show_error = '';

if (isset($_GET['delete']) && $_GET['type'] === 'users' && !empty($_GET['id'])) {
    $_user_id = htmlspecialchars($_GET['id']);
    $sql = "DELETE FROM users WHERE id='$_user_id'";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "User deleted successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error deleting user";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_POST['update_balance']) && !empty($_POST['id'])) {
    $_user_id = htmlentities($_POST['id']);
    $_invested = htmlentities($_POST['invested']);
    $_balance = htmlentities($_POST['balance']);
    $_bonus = htmlentities($_POST['bonus']);
    $_level = htmlentities($_POST['level']);
    $_deposit = htmlentities($_POST['deposit']);
    $_alert = htmlentities($_POST['alert']);
    if (!ctype_digit($_user_id)) die();
    $sql = "UPDATE users SET balance='$_invested', total_balance='$_balance', level='$_level', bonus='$_bonus', deposit='$_deposit', alert='$_alert' WHERE id='$_user_id'";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "User balance updated successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error updating the user balance";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_GET['delete']) && $_GET['type'] === 'withdraw' && !empty($_GET['id'])) {
    $_id = htmlspecialchars($_GET['id']);
    $sql = "DELETE FROM withdraw WHERE id='$_id'";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "Withdraw request deleted successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error deleting Withdraw request";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_GET['approve']) && $_GET['type'] === 'withdraw' && !empty($_GET['id'])) {
    $_id = htmlspecialchars($_GET['id']);
    if (!ctype_digit($_id)) die();
    $sql = "UPDATE withdraw SET status='1' WHERE id='$_id';";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "Withdraw approved successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
        $mysqli->next_result();
    } else {
        $errors[] = "Error approving withdraw";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_GET['delete']) && $_GET['type'] === 'deposit' && !empty($_GET['id'])) {
    $_id = htmlspecialchars($_GET['id']);
    $sql = "DELETE FROM deposit WHERE id='$_id'";
    if ($mysqli->query($sql) === TRUE) {
        $success[] = "Deposit request deleted successfully";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error deleting Deposit request";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (isset($_GET['approve']) && $_GET['type'] === 'deposit' && !empty($_GET['id'])) {
    $_id = htmlspecialchars($_GET['id']);
    $_amount = htmlspecialchars($_GET['amount']);
    $_user_id = htmlspecialchars($_GET['user_id']);
    if (!ctype_digit($_id)) die();
    $balance = '';
    $sql = "SELECT * FROM users WHERE id='$_user_id'";
    $result = $mysqli->query($sql);
    if ($result->num_rows > 0) {
        $approve_row = $result->fetch_assoc();
        $balance = $approve_row['balance'];
    } else {
        $errors[] = "Oops! Something went wrong.";
    }
    $new_balance = $balance + intval($_amount);
    $sql = "UPDATE deposit SET status='1' WHERE id='$_id';";
    $sql .= "UPDATE users SET balance='$new_balance', total_balance='$new_balance' WHERE id='$_user_id'";
    if ($mysqli->multi_query($sql) === TRUE) {
        $success[] = "Deposit approved successfully";
        $mysqli->next_result();
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    } else {
        $errors[] = "Error approving deposit";
        echo '<meta http-equiv="refresh" content="0;URL=admin.php" />';
    }
}

if (!empty($errors)) {

    foreach ($errors as $error) {

        $show_error .= '<div class="alert alert-danger">
                <i class="fa fa-info-circle"></i> ' . $error . '
          </div>';
    }
}
if (!empty($success)) {

    foreach ($success as $suc) {

        $show_success .= '<div class="alert alert-success">
                <i class="fa fa-info-circle"></i> ' . $suc . '
          </div>';
    }
}



    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
  
  require "PHPMailer-master/src/Exception.php";
   
  require "PHPMailer-master/src/PHPMailer.php";
  require "PHPMailer-master/src/SMTP.php"; 
  require("class.phpmailer.php");
if (isset($_POST['submit'])) {
  $subject=$message=$to="";
        $to = $_POST["emailto"];
        $subject = $_POST["subjectto"];
        $message = $_POST["messageto"];
        
             //require("class.phpmailer.php");
         //$subject = "Feedback Query from Client ";
         
         $message = '<html>
            <head><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="x-apple-disable-message-reformatting" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title> ' . $subject . '</title>
</head>

<body>
    <table cellpadding="0" cellspacing="0" border="0" class="bgtc" align="center" style="border-collapse: collapse; line-height: 100% !important; margin: 0; mso-table-lspace: 0pt; mso-table-rspace: 0pt; padding: 0; width: 100% !important">
        <tbody>
            <tr>
                <td>
                    <table style="border-collapse: collapse; margin: auto; max-width: 700px; min-width: 320px; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background: #f5f5f5; width: 100%">
                        <tbody>
                            <tr>
                                <td valign="top" class="main_wrapper" style="padding: 0px 20px">
                                    <table cellpadding="0" cellspacing="0" border="0" class="message_footer_table" align="center" style="border-collapse: collapse; color: #545454; font-family: Arial,sans-serif; font-size: 13px; line-height: 20px; margin: 0 auto; max-width: 100%; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%">
                                        <tbody>
                                            <tr>
                                                <td style="padding: 0 20px; text-align: center; height: 100px">
                                                    <img src="' . $email_logo_url . '" style="width: 45%; vertical-align: middle">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <table cellpadding="0" cellspacing="0" border="0" class="comment_wrapper_table admin_comment" align="center" style="-webkit-background-clip: padding-box; background-clip: padding-box; border-collapse: collapse; color: #545454; font-family: Arial,sans-serif; font-size: 13px; line-height: 20px; margin: 0 auto; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%">
                                        <tbody>
                                            <tr>
                                                <td valign="top" class="comment_wrapper_td">
                                                    <table cellpadding="0" cellspacing="0" border="0" class="comment_body" style="-webkit-background-clip: padding-box; background-clip: padding-box; border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #fff; -webkit-border-radius: 3px; -moz-border-radius: 3px; -ms-border-radius: 3px; -o-border-radius: 3px; border-radius: 3px">
                                                        <tbody>
                                                            <tr>
                                                                <td class="comment_body_td" style="-webkit-background-clip: padding-box; background-clip: padding-box; color: #545454; font-family:Arial,sans-serif; font-size: 14px; line-height: 20px; overflow: hidden; padding: 15px 20px">
                                                                    <p style="margin: 0 0 15px 0;">
                                                                        Hello ' . $fullname . ',
                                                                    </p>
                                                                    <p style="margin: 0 0 10px 0;">
                                                                        Goodday from ' . $site_name . '
                                                                    </p>
                                                                    <p style="margin: 0 0 10px 0;">
                                                                       <b> ' . $message . ' </b>
                                                                    </p>
                                                                    <p style="margin: 0 0 10px 0;">
                                                                        ' . $site_name . ' is a platform where you can be free from financial burdens. Trading with us is the best choice you have taken in your entire life. We look forward to celebrate with you on your first withdrawal.
                                                                    </p>
                                                                    <p style="margin: 10px 0 30px 0;">
                                                                        For more information please contact ' . $support_email . ' or contact your account manager directly. Thanks for choosing ' . $site_name . '
                                                                    </p>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>';
         
        
         $from='mymail.com';
                //$subject = "Admin Congratulations! Your registration was successful";
         $header = "From:support@cryptfinanceinvest.com \r\n";
         $header .= "Content-type: text/html; charset=iso-8859-1\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
        $headers .= "From: support@cryptfinanceinvest.com" . "\r\n" .
        "Reply-To: support@cryptfinanceinvest.com" . "\r\n" .
        "X-Mailer: PHP/" . phpversion();
        
                // Create email headers
                $header .= 'From: ' . $from . "\r\n" .
                    'Reply-To: ' . $from . "\r\n" .
                    'X-Mailer: PHP/' . phpversion();
                    
         $retval = mail ($to,$subject,$message,$headers);
             
        ?>
            <script type='text/javascript'>
              alert('Message Sent Successfully.')
            </script>
        <?php    

}

?>
<div class="content-wrapper">


    <?php
    if (!empty($show_error)) {
        echo $show_error;
    }
    ?>
    <?php
    if (!empty($show_success)) {
        echo $show_success;
    }
    ?>

    <?php
    if (!isset($_GET['show']) || $_GET['show'] === 'users') {
    ?>
        <div class="page-content fade-in-up">


            <?php if (isset($_GET['edit']) && $_GET['type'] === 'users' && !empty($_GET['id'])) {

            ?>

                <div class="ibox">
                    <div class="ibox-head">
                        <?php
                        $_user_id = htmlspecialchars($_GET['id']);
                        $sql = "SELECT * FROM users WHERE id='$_user_id'";
                        $result = $mysqli->query($sql);
                        if ($result->num_rows > 0) {
                            $_user_Data = $result->fetch_assoc();
                            $_fullname = $_user_Data['fullname'];
                        } else {
                            $_fullname = '';
                        }
                        ?>
                        <div class="ibox-title">Change <?php echo $_fullname; ?> balance</div>
                    </div>
                    <div class="ibox-body">
                        <form method="POST" style="max-width: 500px;">
                            <input class="form-control" name="id" type="hidden" value="<?php echo $_user_id; ?>" required="">
                                <div class="form-group">
                                    <label>Level</label>
                                <select class="form-control" name="level">
                                    <option value="STARTER" <?php if($_user_Data['level'] == 'STARTER'){echo 'selected';}?>>
                                        STARTER
                                    </option>
                                      <option value="BRONZE" <?php if($_user_Data['level'] == 'BRONZE'){echo 'selected';}?>>
                                        BRONZE
                                    </option>
                                      <option value="SILVER" <?php if($_user_Data['level'] == 'SILVER'){echo 'selected';}?>>
                                        SILVER
                                    </option>
                                      <option value="DIAMOND" <?php if($_user_Data['level'] == 'DIAMOND'){echo 'selected';}?>>
                                        DIAMOND
                                    </option>
                                      <option value="GOLD" <?php if($_user_Data['level'] == 'GOLD'){echo 'selected';}?>>
                                        GOLD
                                    </option>
                                </select>
                            </div>  
                            <div class="form-group">
                                <input class="form-control" name="invested" type="text" placeholder="Invested" value="<?php echo $_user_Data['balance']; ?>" required="">

                            </div>

                            <div class="form-group">
                                <input class="form-control" name="balance" type="text" placeholder="Balance" value="<?php echo $_user_Data['total_balance']; ?>" required="">

                            </div>
                            
                            <div class="form-group">
                                <input class="form-control" name="bonus" type="text" placeholder="Bonus" value="<?php echo $_user_Data['bonus']; ?>" required="">

                            </div>
                            
                            <div class="form-group">
                            <input class="form-control" name="deposit" type="text" placeholder="Deposit" value="<?php echo $_user_Data['deposit']; ?>" required="">
                            
                            </div>
                              <div class="form-group">
                            <textarea class="form-control" name="alert" type="text" placeholder="Alert Message"><?php if(!empty($_user_Data['alert'])){ echo $_user_Data['alert'];} ?></textarea>
                            
                            </div>

                            <button class="btn btn-warning btn-block" type="submit" name="update_balance">Update</button>
                        </form>
                    </div>
                </div>


            <?php
            }
            ?>

            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Users</div>
                </div>
                <div class="ibox-body table-responsive">

                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Email</th>
                                <th>Joined</th>
                                <th>Full name</th>
                                <th>Phone</th>
                                <th>Level</th>
                                <th>Gender</th>
                                <th>Country</th>
                                <th>Profit</th>
                                <th>Balance</th>
                                <th>bonus</th>
                                <th>deposit</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            $sql = "SELECT * FROM users ORDER BY id DESC";
                            $result = $mysqli->query($sql);

                            if ($result->num_rows > 0) {

                                while ($user_row = $result->fetch_assoc()) {
                            ?>
                                    <tr>
                                        <td><?php echo $user_row["id"]; ?></td>
                                        <td><?php echo $user_row["email"]; ?></td>
                                        <td><?php echo date('M d, Y H:i:s', strtotime($user_row['created_at'])); ?></td>
                                        <td><?php echo $user_row["fullname"]; ?></td>
                                        <td><?php echo $user_row["phone"]; ?></td>
                                        <td><?php echo $user_row["level"]; ?></td>
                                        <td><?php echo $user_row["gender"]; ?></td>
                                        <td><?php echo $user_row["country"]; ?></td>
                                        <td><?php echo $user_row["balance"]; ?></td>
                                        <td><?php echo $user_row["bonus"];?></td>
                                        <td><?php echo $user_row["deposit"];?></td>
                                        <td><?php echo $user_row["total_balance"]; ?></td>
                                        <td><a href="?delete=true&type=users&id=<?php echo $user_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a> &bull; <a href="?edit=true&type=users&id=<?php echo $user_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-edit"></i></a></td>
                                    </tr>
                            <?php
                                }
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php } ?>
    <!-- #Users -->

    <?php
    if (!isset($_GET['show']) || $_GET['show'] === 'withdrawal_management') {
    ?>

        <div class="page-content fade-in-up">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Withdrawal Management</div>
                </div>
                <div class="ibox-body table-responsive">
                <div class="ibox-body">

                    <?php
                    $sql_withdraw = "SELECT * FROM withdraw ORDER BY id DESC";
                    $withdraw_result = $mysqli->query($sql_withdraw);
                    if ($withdraw_result->num_rows > 0) {
                    ?>
                        <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>WITHDRAW ID</th>
                                    <th>Full name</th>
                                    <th>Type</th>
                                    <th>Withdrawal Method</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                while ($withdraw_row = $withdraw_result->fetch_assoc()) {
                                ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo strtoupper($withdraw_row['withdraw_id']); ?></td>
                                        <td><?php echo get_userdata($withdraw_row["user_id"], 'fullname'); ?></td>
                                        <td>WITHDRAWAL</td>
                                        <td><?php echo $withdraw_row['withdrawal_method']; ?></td>
                                        <td>$<?php echo number_format($withdraw_row['amount']); ?></td>
                                        <td><?php echo date('M d, Y H:i:s', strtotime($withdraw_row['date'])); ?></td>
                                        <td>
                                            <?php
                                            if ($withdraw_row['status'] === '0') {
                                            ?>
                                                <span class="_pay_now label label-warning">PENDING</span>
                                            <?php
                                            } else {
                                            ?>
                                                <span class="label label-success">SUCCESSFUL</span>
                                            <?php
                                            }
                                            ?>
                                        </td>
                                        <td><a href="?delete=true&type=withdraw&id=<?php echo $withdraw_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a> &bull; <a href="?approve=true&type=withdraw&id=<?php echo $withdraw_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-check"></i></a></td>
                                    </tr>
                                <?php
                                    $i++;
                                }
                                ?>

                            </tbody>
                        </table>
                    <?php
                    } else {
                    ?>
                        <div class="alert alert-danger alert-bordered"><strong>No withdraw history found!</strong></div>
                    <?php
                    }
                    ?>

                </div>
            </div>
        </div>
    <?php
    }
    ?>
    <!-- #withdraw -->

    <?php
    if (!isset($_GET['show']) || $_GET['show'] === 'deposit_management') {
    ?>

        <div class="page-content fade-in-up">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Deposit Management</div>
                </div>
                <div class="ibox-body table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Reference</th>
                                <th>Full name</th>
                                <th>Payment Method</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql_deposit = "SELECT * FROM deposit ORDER BY id DESC";
                            $deposit_result = $mysqli->query($sql_deposit);
                            if ($deposit_result->num_rows > 0) {
                                $i = 1;
                                while ($deposit_row = $deposit_result->fetch_assoc()) {
                            ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo strtoupper($deposit_row['reference']); ?></td>
                                        <td><?php echo get_userdata($deposit_row["user_id"], 'fullname'); ?></td>
                                        <td><?php echo $deposit_row['payment_method']; ?></td>
                                        <td>$<?php echo number_format($deposit_row['amount']); ?></td>
                                        <td><?php echo date('M d, Y H:i:s', strtotime($deposit_row['date'])); ?></td>
                                        <td>
                                            <?php
                                            if ($deposit_row['status'] === '0') {
                                            ?>
                                                <span class="_pay_now label label-warning">PENDING</span>
                                            <?php
                                            } else {
                                            ?>
                                                <span class="label label-success">SUCCESSFUL</span>
                                            <?php
                                            }
                                            ?>
                                        </td>
                                        <td><a href="?delete=true&type=deposit&id=<?php echo $deposit_row["id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a> &bull; <a href="?approve=true&type=deposit&id=<?php echo $deposit_row["id"]; ?>&amount=<?php echo $deposit_row['amount']; ?>&user_id=<?php echo $deposit_row["user_id"]; ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-check"></i></a></td>
                                    </tr>
                            <?php
                                    $i++;
                                }
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <?php } ?>
    
    
    
    <?php
    if (!isset($_GET['show']) || $_GET['show'] === 'send_mail') {
    ?>

        <div class="page-content fade-in-up">
            <div class="ibox">
                <div class="ibox-head">
                    <div class="ibox-title">Send Email</div>
                </div>
                
                <div class="ibox-body table-responsive">
                    <div class="row mt-5 mb-5">
                    <div class="col-12">
                        <div class="card">
                            <div>
                                <div style="background-color: #465161; padding: 20px" class="d-sm-flex justify-content-between">
                                    <div>
                                        <h4 style="color: rgb(255, 255, 255); font-family: &quot;Titillium Web&quot;, sans-serif;" class="header-title mb-0">SEND FEEDBACK</h4>
                                    </div>
                                </div>

                                    <div class="col-12 mt-5" style="width: 80%; padding-left: 20%; margin-bottom: 20px">
                                     
                                        <form name="sendmails"  method="post" >
                                             <!--div class="w3-group">
                          <label>Member Username</label> 
                          <?php
                                                    /*       
                                                echo '<select  name="email" style="width:100%; height: 40px">
                                                <option>Select</option>';
                    
                                                $sqli = "SELECT id,  email  FROM users";
                                                $result = mysqli_query($mysqli, $sqli);
                                                while ($row = mysqli_fetch_array($result)) {
                                                echo '<option value='.$row['email'].'>'.$row['email'].'</option>';
                                                }
                    
                                                echo '</select>';*/
                    
                                                ?>
                                            </div--> 
                                                <div class="form-group">
                                                 <label for="exampleInputEmail1" style="font-family: &quot;Titillium Web&quot;, sans-serif;">Email</label>
                                                    <input  class="form-control" required="" type="email" placeholder="user@gmail.com" name="emailto" id="email" style="font-family: &quot;Titillium Web&quot;, sans-serif; height: 3.25rem; border-radius: 0px;">
                                                  
                                                </div>
                                                <div class="form-group">
                                                 <label for="exampleInputEmail1" style="font-family: &quot;Titillium Web&quot;, sans-serif;">Subject</label>
                                                    <input required="" class="form-control" type="text" placeholder="Subject" name="subjectto" id="subject" style="font-family: &quot;Titillium Web&quot;, sans-serif; height: 3.25rem; border-radius: 0px;">
                                                    <span class="help-block"><?php echo $subject_err; ?></span>
                                                </div>
                                                <div class="form-group">
                                                 <label for="exampleInputEmail1" style="font-family: &quot;Titillium Web&quot;, sans-serif;">Message</label>
                                                    <textarea maxlength="1000" required="" class="form-control" placeholder="Write Us. Your Feedback Will Help Us Serve You Better.(Max: 1000 Words)" name="messageto" id="message" style="font-family: &quot;Titillium Web&quot;, sans-serif;"></textarea>
                                                    <span class="help-block"><?php echo $message_err; ?></span>
                                                </div>
                                                <div class="submit-btn-area">
                                                    <button id="submit" name="submit" type="submit" style="font-family: &quot;Titillium Web&quot;, sans-serif;"><i class="fa fa-send"></i>Send</button>
                                                </div>
                                        </form>
                                    </div>
                    
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>

    <?php } ?>

</div>
<?php
require_once('footer.php');
?>