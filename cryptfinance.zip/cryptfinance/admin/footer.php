            <footer class="page-footer">
                <div class="font-13"><?php echo date("Y"); ?> &copy; <b><?php echo $site_name; ?></b> - All rights reserved.</div>
                <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
            </footer>
            </div>
            </div>

            <!-- BEGIN PAGA BACKDROPS-->
            <div class="sidenav-backdrop backdrop"></div>
            <div class="preloader-backdrop">
                <div class="page-preloader">Loading</div>
            </div>
            <!-- END PAGA BACKDROPS-->
            <!-- CORE PLUGINS-->
            <script src="/user/assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
            <script src="/user/assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
            <script src="/user/assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
            <script src="/user/assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
            <script src="/user/assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
            <!-- PAGE LEVEL PLUGINS-->
            <script src="/user/assets/vendors/chart.js/dist/Chart.min.js" type="text/javascript"></script>
            <script src="/user/assets/vendors/jvectormap/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
            <script src="/user/assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
            <script src="/user/assets/vendors/jvectormap/jquery-jvectormap-us-aea-en.js" type="text/javascript"></script>
            <!-- CORE SCRIPTS-->
            <script src="/user/assets/js/app.min.js" type="text/javascript"></script>
            <!-- PAGE LEVEL SCRIPTS-->
            <script src="/user/assets/js/scripts/dashboard_1_demo.js" type="text/javascript"></script>


            <!-- File Upload Preview -->
            <script src="/user/assets/js/bootstrap-imageupload.js"></script>
            </body> 
            </html>