<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to welcome page
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: /user/index.php");
    exit;
}

// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$errors = [];
$success = [];
$email = "";
$show_success = $show_error = '';
// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if email is empty
    if (empty(trim($_POST["email"]))) {
        $errors[] = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
    }

    // Validate credentials
    if (empty($errors)) {
        // Prepare a select statement
        $sql = "SELECT id, email, fullname FROM users WHERE email = ?";

        if ($stmt = $mysqli->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("s", $param_email);

            // Set parameters
            $param_email = $email;

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Store result
                $stmt->store_result();

                // Check if email exists, if yes then verify password
                if ($stmt->num_rows == 1) {
                    $stmt->bind_result($id, $email, $fullname);
                    if ($stmt->fetch()) {
                        $token = uniqid();
                        $sql_update = "UPDATE users SET token='$token' WHERE id='$id'";
                        if ($mysqli->query($sql_update) === TRUE) {
                            $reset_token_url = $site_url . '/reset.php?token=' . $token;

                            // To send HTML mail, the Content-type header must be set
                            $from = $support_email;
                            $headers  = 'MIME-Version: 1.0' . "\r\n";
                            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

                            // Create email headers
                            $headers .= 'From: ' . $from . "\r\n" .
                                'Reply-To: ' . $from . "\r\n" .
                                'X-Mailer: PHP/' . phpversion();

                            require_once("email-template/reset.php");

                            // Sending email
                            $subject = "Your Password Reminder For {$site_name}";
                            if (mail($email, $subject, $message, $headers)) {
                               $success[] = "A link to reset your password has been sent to your email address. Follow this link to reset your password.";
                            } else {
                            }
                        } else {
                            $errors[] = "Oops! Something went wrong. Please try again later.";
                        }
                    }
                } else {
                    // email doesn't exist, display a generic error message
                    $errors[] = "User with this email address does not exist. Please try again.";
                }
            } else {
                $errors[] = "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }

    // Close connection
    $mysqli->close();
}
if (!empty($errors)) {

    foreach ($errors as $error) {

        $show_error .= '<div class="alert alert-danger">
                <i class="fa fa-info-circle"></i> ' . $error . '
          </div>';
    }
}
if (!empty($success)) {

    foreach ($success as $suc) {

        $show_success .= '<div class="alert alert-success">
                <i class="fa fa-info-circle"></i> ' . $suc . '
          </div>';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Forgot Password | RemitonInc</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />     
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
        function hideURLbar(){ window.scrollTo(0,1); }
</script>
<!-- //custom-theme -->
<!-- Favicon -->
<link href="img/favicon.png" rel="shortcut icon" type="image/png">
<!-- font-awesome-icons -->
<link href="reg-log/css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="reg-log/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="http://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext" rel="stylesheet">
</head>
<body>
<div class="main">
 <h1><div class="sitelogo" style="background: rgba(1, 0, 21, 0.66); padding: 15px 0 5px;">
        <a href="index.php">
        <img src="img/logo.png" alt="site logo" style="width: 250px;">
        </a>
     </div>
</h1>
<div class="w3_agile_main_grids">
                        <?php
                        if (!empty($show_error)) {
                            echo $show_error;
                        }
                        ?>
                        <?php
                        if (!empty($show_success)) {
                            echo $show_success;
                        }
                        ?>   
        <form method="post" class="agile_form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" role="form" data-toggle="validator">
        <input type="hidden" name="csrf_token" value="1d85ebd879edf9cc8b08a7d76165a1a0">        <fieldset>
            <h3>Forgot Password</h3>
            <div class="form-group agileits_w3layouts_form w3_agileits_margin">
                <div class="wthree_input">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <input type="email" name="email" class="form-control" placeholder="Email Address">
                    <div class="help-block with-errors"></div>
                </div>
            </div>
            <div class="form-group agileits_w3layouts_form">
                <div class="wthree_input">
                    <button type="submit" name="recover" class="btn btn-primary agileinfo_primary submit" style="margin-top: 10px;">Recover Password</button>
                </div>
            </div>
            <div class="clear"></div>
        </fieldset>
    </form>
            <div id="progress">Don't have an account? <a href="register.php">Register</a></div>       
            <div class="agileits_copyright">
                <p>Copyright &copy; 2013 - 2022 RemitonInc. All rights reserved</p>
            </div>
        </div>
    </div>
    <script src="../code.tidio.co_443/m6rddbubygvc2rpacvnoj9qmzawjyh7d.js" async></script></body>

<!-- Mirrored from www.remitoninc.com/forgot-password.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 18 Dec 2022 13:55:29 GMT -->
</html>